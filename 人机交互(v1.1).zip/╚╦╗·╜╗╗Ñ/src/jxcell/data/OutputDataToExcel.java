/* ===========================================================
 * �������̿���SimpleStock
 * ===========================================================
 *
 * Copyright (C) 2015, by ZhouJiFa.
 *
 * Project Info:  SimpleStock
 *
 * ������:		��٥�� 03121394
 * ��Ҫ������Ա����ѩ      03121323
 * 			����      03121331
 * 			��ԥ      03121326
 */

package jxcell.data;

import java.util.List;

import jstockchart.test.DataUtils;
import jstockchart.test.StockElement;

import com.jxcell.View;
/**
 * 
 * @author zhoujifa
 */
public class OutputDataToExcel {

	private DataUtils dataUtils;
	private String inputFilePath;
	private String outputFilePath;
	private View m_view;
	
	public OutputDataToExcel() {
		dataUtils = new DataUtils();
		m_view = new View();
	}
	//�����ļ����������·��
	public void setFilePath(String inputFilePath,String outputFilePath) {
		this.inputFilePath = inputFilePath;
		this.outputFilePath = outputFilePath;
	}
	//���Excel�ļ�����ʽΪxls
	public void output() {
		try {
			m_view.getLock();
			// ����label
			m_view.setTextAsValue(0, 0, "�ɽ�ʱ��");
			m_view.setTextAsValue(0, 1, "�ɽ���");
			m_view.setTextAsValue(0, 2, "�۸�䶯");
			m_view.setTextAsValue(0, 3, "�ɽ���(��)");
			m_view.setTextAsValue(0, 4, "�ɽ���(Ԫ)");
			m_view.setTextAsValue(0, 5, "����");
			
			// ������ֵ
			dataUtils.process(inputFilePath);
			List<StockElement> dataList = dataUtils.getStockElementsList();
//			System.out.println(dataList.size() + " *****");
			// ������ֵ
			
			for (int row = 1; row < dataList.size(); row++) {
				for (int col = 0; col < 6; col++) {
					// ����Excel�����ú���
					// m_view.setFormula(row, col, "rand()");
					switch(col) {
					case 0:
						m_view.setTextAsValue(row, col, dataList.get(row-1).getTranscationTime());
						break;
					case 1:
						m_view.setNumber(row, col, dataList.get(row-1).getPrice());
						break;
					case 2:
						m_view.setNumber(row, col, dataList.get(row-1).getFluctuate());
						break;
					case 3:
						m_view.setNumber(row, col, (long)dataList.get(row-1).getTurnover());
						break;
					case 4:
						m_view.setNumber(row, col, (long)dataList.get(row-1).getTansactionVolume());
						break;
					case 5:
						m_view.setTextAsValue(row, col, dataList.get(row-1).getProperties());
						break;
					}
				}
			}

			m_view.write(outputFilePath);
		} catch (Exception e) {
			System.out.println(e.getMessage());
		} finally {
			m_view.releaseLock();
		}
	}
	//�������Excel����ͼ
	public View getView() {
		return m_view;
	}

	public static void main(String[] args) {
		OutputDataToExcel out = new OutputDataToExcel();
		out.setFilePath("D:\\stock\\2015_03_30\\2015-03-30sh600000.txt", "E:\\haha.xls");
		out.output();
//		com.jxcell.designer.Designer.newDesigner(out.getView());
	}
}
