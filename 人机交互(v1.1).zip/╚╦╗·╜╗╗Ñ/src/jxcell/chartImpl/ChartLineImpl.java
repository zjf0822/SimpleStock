/* ===========================================================
 * �������̿���SimpleStock
 * ===========================================================
 *
 * Copyright (C) 2015, by ZhouJiFa.
 *
 * Project Info:  SimpleStock
 *
 * ������:		��٥�� 03121394
 * ��Ҫ������Ա����ѩ      03121323
 * 			����      03121331
 * 			��ԥ      03121326
 */

package jxcell.chartImpl;

import jxcell.chart.Chart;
import jxcell.chart.ChartDataRange;
import jxcell.chart.ChartPictureRange;

import com.jxcell.CellException;
import com.jxcell.ChartShape;
import com.jxcell.RangeRef;
import com.jxcell.View;
/**
 * 
 * @author zhoujifa
 */
public class ChartLineImpl implements Chart {

	private ChartShape chart;
	private ChartDataRange chartDataRange;
	private ChartPictureRange chartPictureRange;
	private View view;

	public ChartLineImpl(ChartDataRange chartDataRange,
			ChartPictureRange chartPictureRange, View view) {
		this.view = view;
		this.chartDataRange = chartDataRange;
		this.chartPictureRange = chartPictureRange;
	}

	public ChartShape getChart() {
		return chart;
	}

	public void draw() {
		try {
			chart = view.addChart(chartPictureRange.getTopLeftPoint().getRow(),
					chartPictureRange.getTopLeftPoint().getCol(),
					chartPictureRange.getButtonRightPoint().getRow(),
					chartPictureRange.getButtonRightPoint().getCol());

		} catch (Exception e) {
			e.printStackTrace();
		}
		chart.initData(new RangeRef(chartDataRange.getTopLeftPoint().getRow(),
				chartDataRange.getTopLeftPoint().getCol(), chartDataRange
						.getButtonRightPoint().getRow(), chartDataRange
						.getButtonRightPoint().getCol()), true); // Sheet1!$A$2:$E$8

		try {
			chart.setChartType(ChartShape.TypeLine);
		} catch (CellException e) {
			e.printStackTrace();
		}
	}
	
}
