/* ===========================================================
 * �������̿���SimpleStock
 * ===========================================================
 *
 * Copyright (C) 2015, by ZhouJiFa.
 *
 * Project Info:  SimpleStock
 *
 * ������:		��٥�� 03121394
 * ��Ҫ������Ա����ѩ      03121323
 * 			����      03121331
 * 			��ԥ      03121326
 */

package jxcell.chartImpl;

import java.io.IOException;

import jxcell.chart.Chart;
import jxcell.chart.ChartDataRange;
import jxcell.chart.ChartPictureRange;
import jxcell.chart.Point;

import com.jxcell.CellException;
import com.jxcell.ChartShape;
import com.jxcell.RangeRef;
import com.jxcell.View;

/**
 * �������ͼ
 * 
 * @author zhoujifa
 */
public class ChartAreaImpl implements Chart {

	private ChartShape chart;						//���Ƶ�ͼ��������
	private ChartDataRange chartDataRange;			//�����ȡ���ݵķ�Χ
	private ChartPictureRange chartPictureRange;	//������Ƶ�ͼƬ��С��Χ
	private View view;								//Excel ������ͼ

	public ChartAreaImpl(ChartDataRange chartDataRange,
			ChartPictureRange chartPictureRange, View view) {
		this.view = view;
		this.chartDataRange = chartDataRange;
		this.chartPictureRange = chartPictureRange;

//		init();
	}
	
	//��ȡͼ������
	public ChartShape getChart() {
		return chart;
	}

	public void draw() {
		try {
			//Excel��ͼ����ͼ��
			//ָ������ͼ���ķ�Χ
			chart = view.addChart(chartPictureRange.getTopLeftPoint().getRow(),
					chartPictureRange.getTopLeftPoint().getCol(),
					chartPictureRange.getButtonRightPoint().getRow(),
					chartPictureRange.getButtonRightPoint().getCol());

		} catch (Exception e) {
			e.printStackTrace();
		}
		//��ʼ�����ݣ��޶����ݵ�ȡֵ��Χ��ָ������Excel��Ԫ���е�����λ�ã�
		chart.initData(new RangeRef(chartDataRange.getTopLeftPoint().getRow(),
				chartDataRange.getTopLeftPoint().getCol(), chartDataRange
						.getButtonRightPoint().getRow(), chartDataRange
						.getButtonRightPoint().getCol()), true); // Sheet1!$A$2:$E$8

		try {
			chart.setChartType(ChartShape.TypeArea);
		} catch (CellException e) {
			e.printStackTrace();
		}
	}
	
	public static void main(String args [] ) {
		View view;
		view =new View();										
		ChartDataRange chartDataRange = new ChartDataRange(new Point(0,1), new Point(4,7));
		ChartPictureRange chartPictureRange = new ChartPictureRange(new Point(1,9),new Point(9,22));
		
		ChartAreaImpl chart1 = new ChartAreaImpl(chartDataRange,chartPictureRange,view);
		
		ChartPictureRange chartPictureRange2 = new ChartPictureRange(new Point(10,19),new Point(19,32));
		ChartPieImpl chart2 = new ChartPieImpl(chartDataRange, chartPictureRange2, view);
        try {
        	view.read(".\\book.csv");
		} catch (IOException e) {
			e.printStackTrace();
		} catch (CellException e) {
			e.printStackTrace();
		}
        
        chart1.draw();
        chart2.draw();
        try {
			view.write(".\\haha.xls");
		} catch (IOException e) {
			e.printStackTrace();
		} catch (CellException e) {
			e.printStackTrace();
		}
	}
}
