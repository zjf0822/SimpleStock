/* ===========================================================
 * �������̿���SimpleStock
 * ===========================================================
 *
 * Copyright (C) 2015, by ZhouJiFa.
 *
 * Project Info:  SimpleStock
 *
 * ������:		��٥�� 03121394
 * ��Ҫ������Ա����ѩ      03121323
 * 			����      03121331
 * 			��ԥ      03121326
 */

package db4o.dbutils;

import jstockchart.transcation.TranscationDate;
import jstockchart.transcation.TranscationInfo;

import com.db4o.Db4o;
import com.db4o.ObjectContainer;

import db4o.query.DBQueryStockInfoImpl;
/**
 * ��ĳһֻ��Ʊ�Ľ�����Ϣ���浽������ݿ���
 * 
 * @author zhoujifa
 */
public class DBToolsStockInformationImpl implements DBTools {

	private ObjectContainer db;		//Ҫ������Ϣ�����ݿ�
	private TranscationInfo stock;	//������Ϣ
	
	public DBToolsStockInformationImpl(TranscationInfo stock) {
		this.stock = stock;
	}
	
	public void connectToDB() {
		db = Db4o.openFile("db\\" +stock.getStockCode() + ".yap");
	}

	public void saveToDB(Class className) {

	}

	public void saveToDB() {
		db.set(getStock());
	}

	public void closeDB() {
		db.close();
	}

	/**
	 * �õ�������Ϣ
	 * @return the stock
	 */
	public TranscationInfo getStock() {
		return stock;
	}

	/**
	 * ���ý�����Ϣ
	 * 
	 * @param stock the stock to set
	 */
	public void setStock(TranscationInfo stock) {
		this.stock = stock;
	}
	
	public static void main(String[] args) {
//		AnalyseOneDayImpl a = new AnalyseOneDayImpl(
//				"D:\\stock\\2015_03_17\\2015-03-17sh600000.txt");
//		a.analyse();
//		
//		TranscationInfo t = a.getTranscationInfo();
//		DBToolsStockInformationImpl d = new DBToolsStockInformationImpl(t);
//		System.out.println(t);
//		d.connectToDB();
//		d.saveToDB();
//		d.closeDB();
		
		
		TranscationDate t1 = new TranscationDate();
		t1.setDay(17);
		t1.setMonth(3);
		t1.setYear(2015);
		DBQueryStockInfoImpl d1 = new DBQueryStockInfoImpl();
		d1.query("sh600000",t1,1);
		
	}

}
