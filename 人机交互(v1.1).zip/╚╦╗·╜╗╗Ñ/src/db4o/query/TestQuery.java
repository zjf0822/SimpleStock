/* ===========================================================
 * �������̿���SimpleStock
 * ===========================================================
 *
 * Copyright (C) 2015, by ZhouJiFa.
 *
 * Project Info:  SimpleStock
 *
 * ������:		��٥�� 03121394
 * ��Ҫ������Ա����ѩ      03121323
 * 			����      03121331
 * 			��ԥ      03121326
 */

package db4o.query;

import java.util.List;

import jstockchart.transcation.TranscationDate;
import jstockchart.transcation.TranscationInfo;

import org.junit.Test;

import com.db4o.Db4o;
import com.db4o.ObjectContainer;
import com.db4o.query.Predicate;
/**
 * 
 * @author zhoujifa
 */
public class TestQuery {

	@Test
	public void test() {

		final TranscationDate t = new TranscationDate();
		t.setDay(17);
		t.setMonth(3);
		t.setYear(2015);
		
		ObjectContainer db2 = Db4o.openFile("D:\\eclipse_workspace(kepler)\\�˻�����\\db\\sh600000.yap");
		try {
			List<TranscationInfo> list = db2.query(new Predicate<TranscationInfo>() {
				@Override
				public boolean match(TranscationInfo info) {
					// �����������Ͱ�ȫ��
					return info.getTranscationDate().getDay() == t.getDay() &&
							info.getTranscationDate().getMonth() == t.getMonth() &&
							info.getTranscationDate().getYear() == t.getYear();
				}
			});
			for (int x = 0; x < list.size(); x++) {
				System.out.println(list.get(x));
			}
		} finally {
			// �ر�����
			db2.close();
		}
	}

}
