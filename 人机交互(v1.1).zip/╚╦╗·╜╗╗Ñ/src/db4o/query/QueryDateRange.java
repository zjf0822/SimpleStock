/* ===========================================================
 * �������̿���SimpleStock
 * ===========================================================
 *
 * Copyright (C) 2015, by ZhouJiFa.
 *
 * Project Info:  SimpleStock
 *
 * ������:		��٥�� 03121394
 * ��Ҫ������Ա����ѩ      03121323
 * 			����      03121331
 * 			��ԥ      03121326
 */

package db4o.query;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import jstockchart.transcation.TranscationDate;
/**
 * ����Ϊ�����࣬���������������
 * @author zhoujifa
 */
public class QueryDateRange {

	private final Map<Integer,Integer> monthAndDays;

	private TranscationDate date;
	private List<TranscationDate> dateRange;
	
	public QueryDateRange(TranscationDate date) {
		this.date = date;
		
		dateRange = new ArrayList<TranscationDate>();
		
		monthAndDays = new TreeMap<Integer,Integer>();
		monthAndDays.put(1, 31);
		monthAndDays.put(2, 28);
		monthAndDays.put(3, 31);
		monthAndDays.put(4, 30);
		monthAndDays.put(5, 31);
		monthAndDays.put(6, 30);
		monthAndDays.put(7, 31);
		monthAndDays.put(8, 31);
		monthAndDays.put(9, 30);
		monthAndDays.put(10, 31);
		monthAndDays.put(11, 30);
		monthAndDays.put(12, 31);
	}
	
	public List<TranscationDate> getDateRange(int number) {
		execute(number);
		return dateRange;
	}

	private void execute(int number) {
		int Year = date.getYear();
		int Month = date.getMonth();
		int Day = date.getDay();
		if((Year % 4 == 0 && Year % 100 != 0) || Year % 400 == 0 ) {
			monthAndDays.put(2, 29);
		}
		
		int DAY = monthAndDays.get(Month);
		//��������number�Ƿ�Ϸ������Ϸ���ȱʡ����numberΪ1;
		if(number <= 0) {
			number = 1;
		}
		
		for(int i = 0;i < number;i++) {
			TranscationDate date = new TranscationDate();
			
			int day = (Day + i);
			int month = Month;
			int year = Year;

			if(day > DAY) {
				day -= DAY;
				month += 1;
			}
			if(month > 12) {
				month = 1;
				year += 1;
			}
			
			date.setDay(day);
			date.setMonth(month);
			date.setYear(year);
			
			dateRange.add(date);
		}
	}
		
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		TranscationDate t = new TranscationDate();
		t.setDay(30);
		t.setMonth(12);
		t.setYear(2015);
		
		QueryDateRange q = new QueryDateRange(t);
		
		List<TranscationDate> list = q.getDateRange(5);
		for(TranscationDate date : list) {
			System.out.println(date);
		}
	}
}
