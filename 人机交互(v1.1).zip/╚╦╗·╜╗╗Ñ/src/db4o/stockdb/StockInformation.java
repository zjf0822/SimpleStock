/* ===========================================================
 * �������̿���SimpleStock
 * ===========================================================
 *
 * Copyright (C) 2015, by ZhouJiFa.
 *
 * Project Info:  SimpleStock
 *
 * ������:		��٥�� 03121394
 * ��Ҫ������Ա����ѩ      03121323
 * 			����      03121331
 * 			��ԥ      03121326
 */

package db4o.stockdb;

import java.util.Date;
/**
 * 
 * @author zhoujifa
 */
public class StockInformation {

	private double beginValue;		//���̼�
	private double endValue;		//���̼�
	private double maxValue;		//��߼�
	private double minValue;		//��ͼ�
	private Date transcationDate;	//��������
	private double turnover;		//�ɽ���
	private double tansactionVolume;//�ɽ���
	
	private StockCode stockCode;

	/**
	 * @return the beginValue
	 */
	public double getBeginValue() {
		return beginValue;
	}

	/**
	 * @param beginValue the beginValue to set
	 */
	public void setBeginValue(double beginValue) {
		this.beginValue = beginValue;
	}

	/**
	 * @return the endValue
	 */
	public double getEndValue() {
		return endValue;
	}

	/**
	 * @param endValue the endValue to set
	 */
	public void setEndValue(double endValue) {
		this.endValue = endValue;
	}

	/**
	 * @return the transcationDate
	 */
	public Date getTranscationDate() {
		return transcationDate;
	}

	/**
	 * @param transcationDate the transcationDate to set
	 */
	public void setTranscationDate(Date transcationDate) {
		this.transcationDate = transcationDate;
	}

	/**
	 * @return the turnover
	 */
	public double getTurnover() {
		return turnover;
	}

	/**
	 * @param turnover the turnover to set
	 */
	public void setTurnover(double turnover) {
		this.turnover = turnover;
	}

	/**
	 * @return the tansactionVolume
	 */
	public double getTansactionVolume() {
		return tansactionVolume;
	}

	/**
	 * @param tansactionVolume the tansactionVolume to set
	 */
	public void setTansactionVolume(double tansactionVolume) {
		this.tansactionVolume = tansactionVolume;
	}
	
	public StockInformation() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * @return the stockCode
	 */
	public StockCode getStockCode() {
		return stockCode;
	}

	/**
	 * @param stockCode the stockCode to set
	 */
	public void setStockCode(StockCode stockCode) {
		this.stockCode = stockCode;
	}

	/**
	 * @return the maxValue
	 */
	public double getMaxValue() {
		return maxValue;
	}

	/**
	 * @param maxValue the maxValue to set
	 */
	public void setMaxValue(double maxValue) {
		this.maxValue = maxValue;
	}

	/**
	 * @return the minValue
	 */
	public double getMinValue() {
		return minValue;
	}

	/**
	 * @param minValue the minValue to set
	 */
	public void setMinValue(double minValue) {
		this.minValue = minValue;
	}

}
