/* ===========================================================
 * �������̿���SimpleStock
 * ===========================================================
 *
 * Copyright (C) 2015, by ZhouJiFa.
 *
 * Project Info:  SimpleStock
 *
 * ������:		��٥�� 03121394
 * ��Ҫ������Ա����ѩ      03121323
 * 			����      03121331
 * 			��ԥ      03121326
 */

package db4o.stockdb;
/**
 * 
 * @author zhoujifa
 */
public class StockCode {

	private String stockName;
	private String stockCode;
	
	public StockCode() {
		
	}

	
	
	/**
	 * @return the stockName
	 */
	public String getStockName() {
		return stockName;
	}



	/**
	 * @param stockName the stockName to set
	 */
	public void setStockName(String stockName) {
		this.stockName = stockName;
	}



	/**
	 * @return the stockCode
	 */
	public String getStockCode() {
		return stockCode;
	}



	/**
	 * @param stockCode the stockCode to set
	 */
	public void setStockCode(String stockCode) {
		this.stockCode = stockCode;
	}



	@Override
	public String toString() {
		return "StockCode [stockName=" + stockName + ", stockCode=" + stockCode
				+ "]";
	}
	
	
}
