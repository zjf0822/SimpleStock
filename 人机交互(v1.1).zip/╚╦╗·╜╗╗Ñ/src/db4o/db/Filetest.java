/* ===========================================================
 * �������̿���SimpleStock
 * ===========================================================
 *
 * Copyright (C) 2015, by ZhouJiFa.
 *
 * Project Info:  SimpleStock
 *
 * ������:		��٥�� 03121394
 * ��Ҫ������Ա����ѩ      03121323
 * 			����      03121331
 * 			��ԥ      03121326
 */

package db4o.db;

import java.io.File;
import java.io.FilenameFilter;
/**
 * ���ڲ���Filter����
 * @author zhoujifa
 */
class MyFilenameFilter implements FilenameFilter {
	private String externalName; // �������չ��

	public String getExternalName() {
		return externalName;
	}
	//��ʼ���ļ���չ��
	public MyFilenameFilter(String externalName) {
		this.externalName = externalName;
	}
	//�ж��Ƿ���Ҫ����
	public boolean accept(File dir, String fileName) {
		if (fileName.toLowerCase().endsWith("." + this.externalName)) {
			return true;
		}
		return false;
	}
}

public class Filetest {

//	String strPath;
	private File file;
	private String filePath;
	private String fileExternalName;

	public Filetest(String filePath, String fileExternalName) {
		this.filePath = filePath;
		this.fileExternalName = fileExternalName;
		file = new File(filePath);
	}
	
	private void show(File filePath) {
		file = filePath;
		//���ɱ�Ŀ¼�µ��ļ�·��
		File files [] = file.listFiles(new MyFilenameFilter(this.fileExternalName));
		for(int i = 0;i < files.length;i++) {
//			System.out.println(files[i].toString().substring(this.filePath.length() + 1)); 
			System.out.println(files[i].toString());
		}
		//�ݹ���һ����Ŀ¼ 
		File files1 [] = file.listFiles();
		for(int i = 0;i < files1.length;i++) {
			if(files1[i].isDirectory()) {
				show(files1[i]);
			}
		}
	}
	
	public void show() {
//		File files[] = file.listFiles(new MyFilenameFilter(this.fileExternalName));
//		for (int i = 0; i < files.length; i++) {
//			System.out.println(files[i]);
//		}
//
//		File filess[] = file.listFiles();
//		for (int i = 0; i < filess.length; i++) {
//			if (filess[i].isDirectory()) {
//				System.out.println(filess[i] + "**");
//			}
//		}
		
		show(file);
		
//		this.filePath = this.filePath + "\\�½��ļ���";
//		file = new File(this.filePath);
//		MyFilenameFilter ft = new MyFilenameFilter(this.fileExternalName);
//		File files1[] = file.listFiles(ft);
//
//		for (int i = 0; i < files1.length; i++) {
//			System.out.println(files1[i]);
//		}
	}

	public static void main(String args[]) {
		Filetest ft = new Filetest("D:\\stock", "txt");
		ft.show();
	}
}
