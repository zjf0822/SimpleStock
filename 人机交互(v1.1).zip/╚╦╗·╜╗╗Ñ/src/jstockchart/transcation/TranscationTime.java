/* ===========================================================
 * �������̿���SimpleStock
 * ===========================================================
 *
 * Copyright (C) 2015, by ZhouJiFa.
 *
 * Project Info:  SimpleStock
 *
 * ������:		��٥�� 03121394
 * ��Ҫ������Ա����ѩ      03121323
 * 			����      03121331
 * 			��ԥ      03121326
 */

package jstockchart.transcation;

/*
 * ����ʱ�䣬һ�������Ӧһ�������յ�ĳʱ��
 */
/**
 * 
 * @author zhoujifa
 */
public class TranscationTime extends TranscationDate {

	protected int hour;
	protected int minute;
	protected int second;
	protected int millisecond;

	public TranscationTime() {
		super();
	}

	/**
	 * @return the hour
	 */
	public int getHour() {
		return hour;
	}

	/**
	 * @param hour the hour to set
	 */
	public void setHour(int hour) {
		this.hour = hour;
	}

	/**
	 * @return the minute
	 */
	public int getMinute() {
		return minute;
	}

	/**
	 * @param minute the minute to set
	 */
	public void setMinute(int minute) {
		this.minute = minute;
	}

	/**
	 * @return the second
	 */
	public int getSecond() {
		return second;
	}

	/**
	 * @param second the second to set
	 */
	public void setSecond(int second) {
		this.second = second;
	}

	/**
	 * @return the millisecond
	 */
	public int getMillisecond() {
		return millisecond;
	}

	/**
	 * @param millisecond the millisecond to set
	 */
	public void setMillisecond(int millisecond) {
		this.millisecond = millisecond;
	}
	
	
}
