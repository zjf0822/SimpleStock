/* ===========================================================
 * �������̿���SimpleStock
 * ===========================================================
 *
 * Copyright (C) 2015, by ZhouJiFa.
 *
 * Project Info:  SimpleStock
 *
 * ������:		��٥�� 03121394
 * ��Ҫ������Ա����ѩ      03121323
 * 			����      03121331
 * 			��ԥ      03121326
 */

package jstockchart.transcation;
/**
 * 
 * @author zhoujifa
 */
public class TranscationInfo {
	
	private String stockCode;		//��Ʊ����
	
	private double beginValue;		//���̼�
	private double maxValue;		//��߳ɽ���
	private double minValue;		//���̼�
	private double endValue;		//��ͳɽ���
	
	private TranscationDate transcationDate;	//��������
	private TranscationVolume transcationVolume;	//��������
	
	//Constructor Method,��ʼ���������ڣ����̼ۣ���߼ۣ���ͼۣ����̼�
	public TranscationInfo(TranscationDate transcationDate,double beginValue,			
			double maxValue,double minValue,double endValue) {
		this.transcationDate = transcationDate;
		this.beginValue = beginValue;
		this.maxValue = maxValue;
		this.minValue = minValue;
		this.endValue = endValue;
	}
		
	//Constructor Method
	public TranscationInfo() {
		transcationDate = new TranscationDate();
		transcationVolume = new TranscationVolume();
	}

	
	/**
	 * @return the beginValue
	 */
	public double getBeginValue() {
		return beginValue;
	}

	/**
	 * @param beginValue the beginValue to set
	 */
	public void setBeginValue(double beginValue) {
		this.beginValue = beginValue;
	}

	/**
	 * @return the maxValue
	 */
	public double getMaxValue() {
		return maxValue;
	}

	/**
	 * @param maxValue the maxValue to set
	 */
	public void setMaxValue(double maxValue) {
		this.maxValue = maxValue;
	}

	/**
	 * @return the minValue
	 */
	public double getMinValue() {
		return minValue;
	}

	/**
	 * @param minValue the minValue to set
	 */
	public void setMinValue(double minValue) {
		this.minValue = minValue;
	}

	/**
	 * @return the endValue
	 */
	public double getEndValue() {
		return endValue;
	}

	/**
	 * @param endValue the endValue to set
	 */
	public void setEndValue(double endValue) {
		this.endValue = endValue;
	}

	/**
	 * @return the transcationDate
	 */
	public TranscationDate getTranscationDate() {
		return transcationDate;
	}

	/**
	 * @param transcationDate the transcationDate to set
	 */
	public void setTranscationDate(TranscationDate transcationDate) {
		this.transcationDate = transcationDate;
	}

	/**
	 * @return the transcationVolume
	 */
	public TranscationVolume getTranscationVolume() {
		return transcationVolume;
	}

	/**
	 * @param transcationVolume the transcationVolume to set
	 */
	public void setTranscationVolume(TranscationVolume transcationVolume) {
		this.transcationVolume = transcationVolume;
	}

	/**
	 * @return the stockCode
	 */
	public String getStockCode() {
		return stockCode;
	}

	/**
	 * @param stockCode the stockCode to set
	 */
	public void setStockCode(String stockCode) {
		this.stockCode = stockCode;
	}

	@Override
	public String toString() {
		return "TranscationInfo [stockCode=" + stockCode + ", beginValue="
				+ beginValue + ", maxValue=" + maxValue + ", minValue="
				+ minValue + ", endValue=" + endValue + ", transcationDate="
				+ transcationDate + ", transcationVolume=" + transcationVolume
				+ "]";
	}
	
	
	
}
