/* ===========================================================
 * �������̿���SimpleStock
 * ===========================================================
 *
 * Copyright (C) 2015, by ZhouJiFa.
 *
 * Project Info:  SimpleStock
 *
 * ������:		��٥�� 03121394
 * ��Ҫ������Ա����ѩ      03121323
 * 			����      03121331
 * 			��ԥ      03121326
 */

package jstockchart.transcation;
/**
 * 
 * @author zhoujifa
 */
public class TranscationVolume {

	private int totalTranscationVolume;
	
	public TranscationVolume() {

	}
	
	/**
	 * @return the totalTranscationVolume
	 */
	public int getTotalTranscationVolume() {
		return totalTranscationVolume;
	}

	/**
	 * @param totalTranscationVolume the totalTranscationVolume to set
	 */
	public void setTotalTranscationVolume(int totalTranscationVolume) {
		this.totalTranscationVolume = totalTranscationVolume;
	}
	
	public void addTranscationVolume(int volume) {
		setTotalTranscationVolume(totalTranscationVolume + volume);
	}

	@Override
	public String toString() {
		return "TranscationVolume [totalTranscationVolume="
				+ totalTranscationVolume + "]";
	}
	
	
}
