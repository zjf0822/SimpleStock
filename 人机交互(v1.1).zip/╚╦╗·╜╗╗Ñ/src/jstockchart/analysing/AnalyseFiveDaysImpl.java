/* ===========================================================
 * �������̿���SimpleStock
 * ===========================================================
 *
 * Copyright (C) 2015, by ZhouJiFa.
 *
 * Project Info:  SimpleStock
 *
 * ������:		��٥�� 03121394
 * ��Ҫ������Ա����ѩ      03121323
 * 			����      03121331
 * 			��ԥ      03121326
 */

package jstockchart.analysing;

import java.util.ArrayList;
import java.util.List;
/**
 * 
 * @author zhoujifa
 */
public class AnalyseFiveDaysImpl implements Analyse, AnalyseImpl {

	private List<AnalyseOneDayImpl> fiveDaysAnalysis;			//��һ��Ľ�����Ϣ������ΪԪ�أ���¼���ս�����Ϣ�ķ�������
	private List<String> fiveFilePaths;							//�洢����������Ϣ�ļ���·��
	
	/**
	 * @param fiveFilePaths
	 */
	//Constructor Method
	public AnalyseFiveDaysImpl(List<String> fiveFilePaths) {
		this.fiveFilePaths = fiveFilePaths;
		fiveDaysAnalysis = new ArrayList<AnalyseOneDayImpl>();
	}

	/**
	 * 
	 */
	//five days��s analysis
	public void analyse() {
		for(String str : fiveFilePaths) {
			AnalyseOneDayImpl analysis = new AnalyseOneDayImpl(str);
			analysis.analyse();
			fiveDaysAnalysis.add(analysis);
		}
	}
	
	/**
	 * @return fiveDaysAnalysis
	 */
	public List<AnalyseOneDayImpl> getFiveDaysAnalysis() {
		return fiveDaysAnalysis;
	}

	public static void main(String[] args) {
		List<String> fiveFilePaths = new ArrayList<String>();
		fiveFilePaths.add("D:\\stock\\2015_03_04\\2015-03-04sh600000.txt");
		fiveFilePaths.add("D:\\stock\\2015_03_05\\2015-03-05sh600000.txt");
		fiveFilePaths.add("D:\\stock\\2015_03_06\\2015-03-06sh600000.txt");
		fiveFilePaths.add("D:\\stock\\2015_03_09\\2015-03-09sh600000.txt");
		fiveFilePaths.add("D:\\stock\\2015_03_10\\2015-03-10sh600000.txt");
		AnalyseFiveDaysImpl a = new AnalyseFiveDaysImpl(fiveFilePaths);
		a.analyse();
		
		System.out.println("*********************************");
		System.out.println(a.getFiveDaysAnalysis().get(0).getTranscationInfo().getBeginValue());
		System.out.println(a.getFiveDaysAnalysis().get(0).getTranscationInfo().getMaxValue());
		System.out.println(a.getFiveDaysAnalysis().get(0).getTranscationInfo().getMinValue());
		System.out.println(a.getFiveDaysAnalysis().get(0).getTranscationInfo().getEndValue());
		
		System.out.println("*********************************");
		System.out.println(a.getFiveDaysAnalysis().get(1).getTranscationInfo().getBeginValue());
		System.out.println(a.getFiveDaysAnalysis().get(1).getTranscationInfo().getMaxValue());
		System.out.println(a.getFiveDaysAnalysis().get(1).getTranscationInfo().getMinValue());
		System.out.println(a.getFiveDaysAnalysis().get(1).getTranscationInfo().getEndValue());
		
		System.out.println("*********************************");
		System.out.println(a.getFiveDaysAnalysis().get(2).getTranscationInfo().getBeginValue());
		System.out.println(a.getFiveDaysAnalysis().get(2).getTranscationInfo().getMaxValue());
		System.out.println(a.getFiveDaysAnalysis().get(2).getTranscationInfo().getMinValue());
		System.out.println(a.getFiveDaysAnalysis().get(2).getTranscationInfo().getEndValue());
		
		System.out.println("*********************************");
		System.out.println(a.getFiveDaysAnalysis().get(3).getTranscationInfo().getBeginValue());
		System.out.println(a.getFiveDaysAnalysis().get(3).getTranscationInfo().getMaxValue());
		System.out.println(a.getFiveDaysAnalysis().get(3).getTranscationInfo().getMinValue());
		System.out.println(a.getFiveDaysAnalysis().get(3).getTranscationInfo().getEndValue());
		
		System.out.println("*********************************");
		System.out.println(a.getFiveDaysAnalysis().get(4).getTranscationInfo().getBeginValue());
		System.out.println(a.getFiveDaysAnalysis().get(4).getTranscationInfo().getMaxValue());
		System.out.println(a.getFiveDaysAnalysis().get(4).getTranscationInfo().getMinValue());
		System.out.println(a.getFiveDaysAnalysis().get(4).getTranscationInfo().getEndValue());

	}
}
