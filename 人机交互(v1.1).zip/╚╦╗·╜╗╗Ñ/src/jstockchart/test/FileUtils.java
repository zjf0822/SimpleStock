/* ===========================================================
 * �������̿���SimpleStock
 * ===========================================================
 *
 * Copyright (C) 2015, by ZhouJiFa.
 *
 * Project Info:  SimpleStock
 *
 * ������:		��٥�� 03121394
 * ��Ҫ������Ա����ѩ      03121323
 * 			����      03121331
 * 			��ԥ      03121326
 */

package jstockchart.test;

/*
 * ������, �ļ��Ļ�������, ��ȡreader �ر��ļ���
 */

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
/**
 * 
 * @author zhoujifa
 */
public class FileUtils {

	private FileReader fileReader;
	private BufferedReader bufferedReader;
	private String filePath;

	
	/**
	 * 
	 */
	public FileUtils() {
		super();
	}
	
	
	/**
	 * @return the filePath
	 */
	public String getFilePath() {
		return filePath;
	}

	/**
	 * @param filePath the filePath to set
	 */
	public void setFilePath(String filePath) {
		this.filePath = filePath;
	}

	/**
	 * @return the bufferedReader
	 */
	public BufferedReader getBufferedReader() {
		try {
			bufferedReader = new BufferedReader(new FileReader(new File(filePath)));
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		
		return bufferedReader;
	}
	
	/**
	 * ʵ����bufferedReader
	 */
	private void setBufferedReader() {
		try {
			bufferedReader = new BufferedReader(new FileReader(new File(filePath)));
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * @return the fileReader
	 */
	public FileReader getFileReader(String filePath) {
		try {
			fileReader = new FileReader(new File(filePath));
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		
		return fileReader;
	}
	
	/**
	 * ���ļ���fileReader��bufferedReader�ر�
	 */
	private void fileClose() {
		try {
			if(fileReader != null) {
				fileReader.close();
			}
			if(bufferedReader != null) {
				bufferedReader.close();
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * ����ɨ���ļ�������ȡ������String���ʹ洢������Ȼ��add to List<String> list
	 * 
	 * @return the list
	 */
	public List<String> readFile() {
		List<String> list = new ArrayList<String>();
		String str = null;
		setBufferedReader();
		
		try {
			str = bufferedReader.readLine();
			//�ļ���Ч
			if(str.contains("<script")) {
				fileClose();
				
				return list;
			} else {
				while((str = bufferedReader.readLine()) != null) {
					list.add(str);
				}
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		fileClose();
		
		return list;
	}
	
	public static void main(String[] args) {
		DataProcessImpl dataProcessImpl = new DataProcessImpl();
		FileUtils utils = new FileUtils();
		
		utils.setFilePath("D:\\stock\\2015-03-26sh600000.txt");
//		BufferedReader reader = utils.getBufferedReader();
		for(String str : utils.readFile()) {
			dataProcessImpl.resolve(str);
			double info [] = dataProcessImpl.getInformation();
			System.out.println(dataProcessImpl.getTranscationTime() + " " + info[0] + " " + info[1] + " " +
					info[2] + " " + info[3] + " " + dataProcessImpl.getProperties());
			
		}
	}
}
