/* ===========================================================
 * �������̿���SimpleStock
 * ===========================================================
 *
 * Copyright (C) 2015, by ZhouJiFa.
 *
 * Project Info:  SimpleStock
 *
 * ������:		��٥�� 03121394
 * ��Ҫ������Ա����ѩ      03121323
 * 			����      03121331
 * 			��ԥ      03121326
 */

package jstockchart.test;

/*
 * ��ĳ�ļ���ÿһ�еĹ�Ʊ�����洢����
 */

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import jstockchart.transcation.TranscationInfo;
/**
 * 
 * @author zhoujifa
 */
public class DataUtils {

	private StockElement stockElement;
	private List<StockElement> list;
	private FileUtils fileUtils;
	private DataProcessImpl dataProcessImpl;
	
	public DataUtils() {
		list = new ArrayList<StockElement>();
		fileUtils = new FileUtils();
		dataProcessImpl = new DataProcessImpl();
	}
	
	/**
	 * @return the stockElement
	 */
	public StockElement getStockElement() {
		return stockElement;
	}
	
	/**
	 * ����stockElement
	 * 
	 * @param transcationTime,num[] (����DataProcessImpl��resolve method),
	 * 		  properties (��DataProcessImpl��ȡ),
	 * 		  hour,minute,second
	 */
	public void setStockElement(String transcationTime,double num [],String properties,int hour,int minute,int second) {
		stockElement = new StockElement();
		
		stockElement.setTranscationTime(transcationTime);
		stockElement.setPrice(num[0]);
		stockElement.setFluctuate(num[1]);
		stockElement.setTurnover(num[2]);
		stockElement.setTansactionVolume(num[3]);
		stockElement.setProperties(properties);
		stockElement.setHour(hour);
		stockElement.setMinute(minute);
		stockElement.setSecond(second);
	}

	/**
	 * @param filePath
	 */
	public void process(String filePath) {
		List<String> list = new ArrayList<String>();
		
		fileUtils.setFilePath(filePath);
		list = fileUtils.readFile();
		//��ȡÿһ�е����ݣ����뵽List<StockElement>��
		for(String str : list) {
			dataProcessImpl.resolve(str);
			setStockElement(dataProcessImpl.getTranscationTime(),dataProcessImpl.getInformation(),dataProcessImpl.getProperties(),
					dataProcessImpl.getHour(),dataProcessImpl.getMinute(),dataProcessImpl.getSecond());
			StockElement stockElement = getStockElement();

			this.list.add(stockElement);
		}		
	}
	
	/**
	 * @return the list
	 */
	public List<StockElement> getStockElementsList() {
		//�ֽ����ݷ�ת����Ϊ���ص����ļ�����ʱ��ļ�¼�ǵ��ŵģ����Բɼ�������ʱ����������������Ҫ��תList
		reverse();
		return list;
	}
	
	/**
	 * reverse the list
	 */
	private void reverse() {
		Collections.reverse(list);
	}
	
	public static void main(String[] args) {
		DataUtils utils = new DataUtils();
		utils.process("D:\\stock\\2015_03_30\\2015-03-30sh600000.txt");
		List<StockElement> list = utils.getStockElementsList();
		
//		utils.process("D:\\stock\\2015-06-12sh600551.txt");
//		List<StockElement>list1 = utils.getStockElementsList();
		
		if(list.size() > 0) {
			for(StockElement obj : list) {
				System.out.println(obj);
			}
		} else {
			System.out.println("there is no useful file");
		}
	}
}
