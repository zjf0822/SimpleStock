/* ===========================================================
 * JStockChart : an extension of JFreeChart for financial market
 * ===========================================================
 *
 * Copyright (C) 2009, by Sha Jiang.
 *
 * Project Info:  http://code.google.com/p/jstockchart
 *
 * This library is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU Lesser General Public License as published by 
 * the Free Software Foundation; either version 2.1 of the License, or 
 * (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful, but 
 * WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
 * or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public 
 * License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, 
 * USA.  
 *
 * [Java is a trademark or registered trademark of Sun Microsystems, Inc. 
 * in the United States and other countries.]
 */

package jstockchart.test;

import java.io.IOException;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.jfree.chart.ChartFrame;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.SegmentedTimeline;
import org.jfree.data.Range;
import org.jfree.data.time.Minute;
import org.jstockchart.JStockChartFactory;
import org.jstockchart.area.PriceArea;
import org.jstockchart.area.TimeseriesArea;
import org.jstockchart.area.VolumeArea;
import org.jstockchart.axis.TickAlignment;
import org.jstockchart.axis.logic.CentralValueAxis;
import org.jstockchart.axis.logic.LogicDateAxis;
import org.jstockchart.axis.logic.LogicNumberAxis;
import org.jstockchart.dataset.TimeseriesDataset;
import org.jstockchart.model.TimeseriesItem;
import org.jstockchart.util.DateUtils;
/**
 * 
 * @author zhoujifa
 */
public class TimeseriesChartDemo {

	public static void main(String[] args) throws IOException {

		List<TimeseriesItem> data = new ArrayList<TimeseriesItem>();
		
		//��������
		addTimeseriesItem(data);

		// the 'timeline' indicates the segmented time range '00:00-11:30, 13:00-24:00'.
		SegmentedTimeline timeline = new SegmentedTimeline(
				SegmentedTimeline.MINUTE_SEGMENT_SIZE, 1351, 89);
		timeline.setStartTime(SegmentedTimeline.firstMondayAfter1900() + 780
				* SegmentedTimeline.MINUTE_SEGMENT_SIZE);
		
		// Creates timeseries data set.
		TimeseriesDataset dataset = new TimeseriesDataset(Minute.class, 1,timeline, true);
		dataset.addDataItems(data);

		// Creates logic price axis.
		CentralValueAxis logicPriceAxis = new CentralValueAxis(
				new Double("12"), new Range(
						dataset.getMinPrice().doubleValue(), dataset
								.getMaxPrice().doubleValue()), 9,
				new DecimalFormat(".00"));
		PriceArea priceArea = new PriceArea(logicPriceAxis);

		// Creates logic volume axis.
		LogicNumberAxis logicVolumeAxis = new LogicNumberAxis(new Range(dataset
				.getMinVolume().doubleValue(), dataset.getMaxVolume()
				.doubleValue()), 5, new DecimalFormat("0"));
		VolumeArea volumeArea = new VolumeArea(logicVolumeAxis);

		TimeseriesArea timeseriesArea = new TimeseriesArea(priceArea,
				volumeArea, createlogicDateAxis(DateUtils
						.createDate(2015, 1, 1)));
		
		JFreeChart jfreechart = JStockChartFactory.createTimeseriesChart(
				"Timeseries Chart Demo", dataset, timeline, timeseriesArea,true);

		ChartFrame chartFrame = new ChartFrame("StockKLine", jfreechart);
		// chartҪ����Java��������У�ChartFrame�̳���java��Jframe�ࡣ�õ�һ�������������Ƿ��ڴ������Ͻǵģ��������м�ı��⡣
		chartFrame.pack(); // �Ժ��ʵĴ�Сչ��ͼ��
		chartFrame.setVisible(true);// ͼ���Ƿ�ɼ�
	}
	
	private static void addTimeseriesItem(List<TimeseriesItem> data) {
		data.add(new TimeseriesItem(DateUtils.createDate(2015, 1, 1, 9, 35, 0, 0),10,1000));
		data.add(new TimeseriesItem(DateUtils.createDate(2015, 1, 1, 9, 36, 0, 0),11,200));
		data.add(new TimeseriesItem(DateUtils.createDate(2015, 1, 1, 9, 37, 0, 0),11.2,100));
//		data.add(new TimeseriesItem(DateUtils.createDate(2015, 1, 1, 9, 37, 10, 0),10,4000));
//		data.add(new TimeseriesItem(DateUtils.createDate(2015, 1, 1, 9, 37, 20, 0),13,8000));
//		data.add(new TimeseriesItem(DateUtils.createDate(2015, 1, 1, 9, 37, 30, 0),13.8,1000));
//		data.add(new TimeseriesItem(DateUtils.createDate(2015, 1, 1, 9, 37, 40, 0),14,1000));
//		data.add(new TimeseriesItem(DateUtils.createDate(2015, 1, 1, 9, 37, 50, 0),14,1000));
		data.add(new TimeseriesItem(DateUtils.createDate(2015, 1, 1, 9, 38, 0, 0),10,4000));
		data.add(new TimeseriesItem(DateUtils.createDate(2015, 1, 1, 9, 39, 0, 0),13,8000));
		data.add(new TimeseriesItem(DateUtils.createDate(2015, 1, 1, 9, 40, 0, 0),13.8,1000));
		data.add(new TimeseriesItem(DateUtils.createDate(2015, 1, 1, 9, 41, 0, 0),14,1000));
		data.add(new TimeseriesItem(DateUtils.createDate(2015, 1, 1, 9, 42, 0, 0),14,1000));
		data.add(new TimeseriesItem(DateUtils.createDate(2015, 1, 1, 9, 43, 0, 0),14.8,1000));
		data.add(new TimeseriesItem(DateUtils.createDate(2015, 1, 1, 9, 44, 0, 0),13,1000));
		data.add(new TimeseriesItem(DateUtils.createDate(2015, 1, 1, 9, 45, 0, 0),10,1000));
		data.add(new TimeseriesItem(DateUtils.createDate(2015, 1, 1, 9, 46, 0, 0),11,200));
		data.add(new TimeseriesItem(DateUtils.createDate(2015, 1, 1, 9, 47, 0, 0),11.2,100));
		data.add(new TimeseriesItem(DateUtils.createDate(2015, 1, 1, 9, 48, 0, 0),10,4000));
		data.add(new TimeseriesItem(DateUtils.createDate(2015, 1, 1, 9, 49, 0, 0),13,8000));
		data.add(new TimeseriesItem(DateUtils.createDate(2015, 1, 1, 9, 50, 0, 0),13.8,1000));
		data.add(new TimeseriesItem(DateUtils.createDate(2015, 1, 1, 9, 51, 0, 0),14,1000));
		data.add(new TimeseriesItem(DateUtils.createDate(2015, 1, 1, 9, 52, 0, 0),14,1000));
		data.add(new TimeseriesItem(DateUtils.createDate(2015, 1, 1, 9, 53, 0, 0),14.8,1000));
		data.add(new TimeseriesItem(DateUtils.createDate(2015, 1, 1, 9, 55, 0, 0),13,1000));
		data.add(new TimeseriesItem(DateUtils.createDate(2015, 1, 1, 9, 56, 0, 0),10,1000));
		data.add(new TimeseriesItem(DateUtils.createDate(2015, 1, 1, 9, 57, 0, 0),11,200));
		data.add(new TimeseriesItem(DateUtils.createDate(2015, 1, 1, 9, 58, 0, 0),11.2,100));
		data.add(new TimeseriesItem(DateUtils.createDate(2015, 1, 1, 9, 59, 0, 0),10,4000));
		data.add(new TimeseriesItem(DateUtils.createDate(2015, 1, 1, 10, 0, 0, 0),13,8000));
		data.add(new TimeseriesItem(DateUtils.createDate(2015, 1, 1, 10, 1, 0, 0),13.8,1000));
		data.add(new TimeseriesItem(DateUtils.createDate(2015, 1, 1, 10, 2, 0, 0),14,1000));
		data.add(new TimeseriesItem(DateUtils.createDate(2015, 1, 1, 10, 3, 0, 0),14,1000));
		data.add(new TimeseriesItem(DateUtils.createDate(2015, 1, 1, 10, 4, 0, 0),14.8,1000));
		data.add(new TimeseriesItem(DateUtils.createDate(2015, 1, 1, 10, 5, 0, 0),13,1000));
		data.add(new TimeseriesItem(DateUtils.createDate(2015, 1, 1, 10, 6, 0, 0),10,1000));
		data.add(new TimeseriesItem(DateUtils.createDate(2015, 1, 1, 10, 7, 0, 0),11,200));
		data.add(new TimeseriesItem(DateUtils.createDate(2015, 1, 1, 10, 8, 0, 0),11.2,100));
		data.add(new TimeseriesItem(DateUtils.createDate(2015, 1, 1, 10, 9, 0, 0),10,4000));
		data.add(new TimeseriesItem(DateUtils.createDate(2015, 1, 1, 10, 10, 0, 0),10,8000));
		data.add(new TimeseriesItem(DateUtils.createDate(2015, 1, 1, 10, 11, 0, 0),10.8,1000));
		data.add(new TimeseriesItem(DateUtils.createDate(2015, 1, 1, 10, 12, 0, 0),10,1000));
		data.add(new TimeseriesItem(DateUtils.createDate(2015, 1, 1, 10, 13, 0, 0),10,1000));
		data.add(new TimeseriesItem(DateUtils.createDate(2015, 1, 1, 10, 14, 0, 0),10.8,1000));
		data.add(new TimeseriesItem(DateUtils.createDate(2015, 1, 1, 10, 15, 0, 0),10,1000));
		data.add(new TimeseriesItem(DateUtils.createDate(2015, 1, 1, 10, 16, 0, 0),10,1000));
		data.add(new TimeseriesItem(DateUtils.createDate(2015, 1, 1, 10, 17, 0, 0),11,200));
		data.add(new TimeseriesItem(DateUtils.createDate(2015, 1, 1, 10, 18, 0, 0),11.2,100));
		data.add(new TimeseriesItem(DateUtils.createDate(2015, 1, 1, 10, 20, 0, 0),10,4000));
		data.add(new TimeseriesItem(DateUtils.createDate(2015, 1, 1, 10, 25, 0, 0),10,8000));
		data.add(new TimeseriesItem(DateUtils.createDate(2015, 1, 1, 10, 30, 0, 0),10.8,1000));
		data.add(new TimeseriesItem(DateUtils.createDate(2015, 1, 1, 10, 35, 0, 0),10,1000));
		data.add(new TimeseriesItem(DateUtils.createDate(2015, 1, 1, 11, 0, 0, 0),10,1000));
		data.add(new TimeseriesItem(DateUtils.createDate(2015, 1, 1, 11, 35, 0, 0),10.8,1000));
		data.add(new TimeseriesItem(DateUtils.createDate(2015, 1, 1, 13, 10, 0, 0),10,1000));
		data.add(new TimeseriesItem(DateUtils.createDate(2015, 1, 1, 13, 11, 0, 0),10,1000));
		data.add(new TimeseriesItem(DateUtils.createDate(2015, 1, 1, 13, 12, 0, 0),11,200));
		data.add(new TimeseriesItem(DateUtils.createDate(2015, 1, 1, 13, 15, 0, 0),11.2,100));
		data.add(new TimeseriesItem(DateUtils.createDate(2015, 1, 1, 13, 18, 0, 0),10,4000));
		data.add(new TimeseriesItem(DateUtils.createDate(2015, 1, 1, 13, 20, 0, 0),10,8000));
		data.add(new TimeseriesItem(DateUtils.createDate(2015, 1, 1, 13, 25, 0, 0),10.8,1000));
		data.add(new TimeseriesItem(DateUtils.createDate(2015, 1, 1, 13, 35, 0, 0),10,1000));
		data.add(new TimeseriesItem(DateUtils.createDate(2015, 1, 1, 13, 37, 0, 0),10,1000));
		data.add(new TimeseriesItem(DateUtils.createDate(2015, 1, 1, 13, 38, 0, 0),10.8,1000));
		data.add(new TimeseriesItem(DateUtils.createDate(2015, 1, 1, 13, 40, 0, 0),10,1000));
		data.add(new TimeseriesItem(DateUtils.createDate(2015, 1, 1, 13, 45, 0, 0),10,1000));
		data.add(new TimeseriesItem(DateUtils.createDate(2015, 1, 1, 13, 50, 0, 0),11,200));
		data.add(new TimeseriesItem(DateUtils.createDate(2015, 1, 1, 13, 55, 0, 0),11.2,100));
		data.add(new TimeseriesItem(DateUtils.createDate(2015, 1, 1, 14, 0, 0, 0),10,4000));
		data.add(new TimeseriesItem(DateUtils.createDate(2015, 1, 1, 14, 25, 0, 0),11,8000));
		data.add(new TimeseriesItem(DateUtils.createDate(2015, 1, 1, 14, 30, 0, 0),11.8,1000));
		data.add(new TimeseriesItem(DateUtils.createDate(2015, 1, 1, 14, 35, 0, 0),11,1000));
		data.add(new TimeseriesItem(DateUtils.createDate(2015, 1, 1, 14, 40, 0, 0),11,1000));
		data.add(new TimeseriesItem(DateUtils.createDate(2015, 1, 1, 14, 45, 0, 0),11.8,1000));
		data.add(new TimeseriesItem(DateUtils.createDate(2015, 1, 1, 14, 50, 0, 0),13,1000));
		data.add(new TimeseriesItem(DateUtils.createDate(2015, 1, 1, 14, 55, 0, 0),10,1000));
	}

	// Specifies date axis ticks.
	private static LogicDateAxis createlogicDateAxis(Date baseDate) {
		LogicDateAxis logicDateAxis = new LogicDateAxis(baseDate,
				new SimpleDateFormat("HH:mm"));
		
		logicDateAxis.addDateTick("09:30", TickAlignment.START);
		logicDateAxis.addDateTick("10:00");
		logicDateAxis.addDateTick("10:30");
		logicDateAxis.addDateTick("11:00");
		logicDateAxis.addDateTick("11:30", TickAlignment.END);
		logicDateAxis.addDateTick("13:00", TickAlignment.START);
		logicDateAxis.addDateTick("13:30");
		logicDateAxis.addDateTick("14:00");
		logicDateAxis.addDateTick("14:30");
		logicDateAxis.addDateTick("15:00", TickAlignment.END);
		
		return logicDateAxis;
	}
}
