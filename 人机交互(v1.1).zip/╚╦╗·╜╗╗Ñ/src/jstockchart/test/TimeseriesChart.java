/* ===========================================================
 * �������̿���SimpleStock
 * ===========================================================
 *
 * Copyright (C) 2015, by ZhouJiFa.
 *
 * Project Info:  SimpleStock
 *
 * ������:		��٥�� 03121394
 * ��Ҫ������Ա����ѩ      03121323
 * 			����      03121331
 * 			��ԥ      03121326
 */

package jstockchart.test;

import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import jexcel.data.InputDataFromExcel;

import org.jfree.chart.ChartFrame;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.SegmentedTimeline;
import org.jfree.data.Range;
import org.jfree.data.time.Minute;
import org.jstockchart.JStockChartFactory;
import org.jstockchart.area.PriceArea;
import org.jstockchart.area.TimeseriesArea;
import org.jstockchart.area.VolumeArea;
import org.jstockchart.axis.TickAlignment;
import org.jstockchart.axis.logic.CentralValueAxis;
import org.jstockchart.axis.logic.LogicDateAxis;
import org.jstockchart.axis.logic.LogicNumberAxis;
import org.jstockchart.dataset.TimeseriesDataset;
import org.jstockchart.model.TimeseriesItem;
import org.jstockchart.util.DateUtils;
/**
 * 
 * @author zhoujifa
 */
public class TimeseriesChart {

	private DataUtils dataUtils;
	private String dataPath;
	private double firstPrice;
	private List<TimeseriesItem> timeSeriesItmeList;
	private String stockName;
	
	/**
	 * @param dataPath
	 */
	public TimeseriesChart(String dataPath) {
		dataUtils = new DataUtils();
		this.dataPath = dataPath;
		timeSeriesItmeList = new ArrayList<TimeseriesItem>();
	}

	/**
	 * @return timeSeriesItmeList
	 */
	private List<TimeseriesItem> getTimeseriesItem() {
		List<StockElement> stockElementList = null;
		//��������txt�ļ�
		if(dataPath.contains(".txt")) {
			dataUtils.process(dataPath);
			stockElementList = dataUtils.getStockElementsList();
		}
		//��������xls�ļ�
		else if(dataPath.contains(".xls") || dataPath.contains(".xlsx")) {
			stockElementList = new InputDataFromExcel(dataPath).getStockElementList();
		}
		//�������ļ�ѹ���ϲ�����
		stockElementList = new CompressData().compress(stockElementList);
		//ѭ������ÿһ��Ԫ�أ�
		//ÿѭ��һ�Σ��½�һ��TimeseriesItemԪ��
		for(StockElement element : stockElementList) {
			Date date = DateUtils.createDate(element.getYear() + 2015, element.getMonth() + 1,  
					element.getDay() + 1, element.getHour(), 
					element.getMinute(), element.getSecond(),
					element.getMillisecond());
			
			TimeseriesItem timeSeriesItem = new TimeseriesItem(date, element.getPrice(), 
					element.getTurnover());
			timeSeriesItmeList.add(timeSeriesItem);

		}
		
		if(stockElementList.size() > 0) {
			firstPrice = stockElementList.get(0).getPrice();
		} else {
			for(int i = 10;i < 12;i++) {
				for(int j = 0; j < 60;j++) {
					timeSeriesItmeList.add(new TimeseriesItem(DateUtils.createDate(2015, 1, 1, i, j, 0, 0),10.00,1));
				}
			}
			for(int i = 13;i < 15;i++) {
				for(int j = 0;j < 60;j++) {
					timeSeriesItmeList.add(new TimeseriesItem(DateUtils.createDate(2015, 1, 1, i, j, 0, 0),10.00,1));
				}
			}
			firstPrice = 10;
		}
		
		return timeSeriesItmeList;
	}	
	
	/**
	 * 
	 * @param stockName set the stockName to stockName
	 */
	public void setStockName(String stockName) {
		this.stockName = stockName;
	}
	
	/**
	 * ���ƹ�Ʊ����ʱ��ͼ
	 * 
	 * @return jfreechart
	 */
	public JFreeChart drawChart() {
		//'data' is a list of TimeseriesItem instances.
		List<TimeseriesItem> data = getTimeseriesItem();
		//��������
		// the 'timeline' indicates the segmented time range '00:00-11:30, 13:00-24:00'.
		SegmentedTimeline timeline = new SegmentedTimeline(
				SegmentedTimeline.MINUTE_SEGMENT_SIZE, 1351, 89);
		timeline.setStartTime(SegmentedTimeline.firstMondayAfter1900() + 780
				* SegmentedTimeline.MINUTE_SEGMENT_SIZE);
		
		// Creates timeseries data set.
		TimeseriesDataset dataset = new TimeseriesDataset(Minute.class, 1,timeline, true);
		dataset.addDataItems(data);

		// Creates logic price axis.
		CentralValueAxis logicPriceAxis = new CentralValueAxis(
				new Double(String.valueOf(firstPrice)), new Range(
						dataset.getMinPrice().doubleValue(), dataset
								.getMaxPrice().doubleValue()), 9,
				new DecimalFormat(".00"));
		
		//Creates price area
		PriceArea priceArea = new PriceArea(logicPriceAxis);

		// Creates logic volume axis.
		LogicNumberAxis logicVolumeAxis = new LogicNumberAxis(new Range(dataset
				.getMinVolume().doubleValue(), dataset.getMaxVolume()
				.doubleValue()), 5, new DecimalFormat("0"));
		VolumeArea volumeArea = new VolumeArea(logicVolumeAxis);

		//Creates time series area
		TimeseriesArea timeseriesArea = new TimeseriesArea(priceArea,
				volumeArea, createlogicDateAxis(DateUtils
						.createDate(2015, 1, 1)));

		//Create chart
		JFreeChart jfreechart = JStockChartFactory.createTimeseriesChart(
				stockName, dataset, timeline, timeseriesArea,true);

		
		/*
		 * ���Ҫ��������ͼ���ⲻҪ������Ĵ���ע��
		 * ���ֻҪJFreeChart����������ע�͵�
		 */
//		ChartFrame chartFrame = new ChartFrame("StockKLine", jfreechart);
//		// chartҪ����Java��������У�ChartFrame�̳���java��Jframe�ࡣ�õ�һ�������������Ƿ��ڴ������Ͻǵģ��������м�ı��⡣
//		chartFrame.pack(); // �Ժ��ʵĴ�Сչ��ͼ��
//		chartFrame.setVisible(true);// ͼ���Ƿ�ɼ�
		
		return jfreechart;
	}
	
	/**
	 * 
	 * @param baseDate
	 * @return
	 */
	private static LogicDateAxis createlogicDateAxis(Date baseDate) {
		LogicDateAxis logicDateAxis = new LogicDateAxis(baseDate,
				new SimpleDateFormat("HH:mm"));
		//����ʱ����ͼ����ʱ����
		//ÿ���СʱΪһ����
		//9:30Ϊ���̿���ʱ�䣬11:30Ϊ���̽���ʱ��
		//13:30Ϊ�����̿���ʱ�䣬15:00Ϊ��������ʱ��
		logicDateAxis.addDateTick("09:30", TickAlignment.START);
		logicDateAxis.addDateTick("10:00");
		logicDateAxis.addDateTick("10:30");
		logicDateAxis.addDateTick("11:00");
		logicDateAxis.addDateTick("11:30", TickAlignment.END);
		logicDateAxis.addDateTick("13:00", TickAlignment.START);
		logicDateAxis.addDateTick("13:30");
		logicDateAxis.addDateTick("14:00");
		logicDateAxis.addDateTick("14:30");
		logicDateAxis.addDateTick("15:00", TickAlignment.END);
		
		return logicDateAxis;
	}
		
	public static void main(String[] args) {
//		TimeseriesChart chart = new TimeseriesChart("D:\\stock\\2015_03_04\\2015-03-04sh600000.txt");
		TimeseriesChart chart = new TimeseriesChart("E:\\2015-06-12sh600282.txt");
		chart.setStockName("hahaha");
		chart.drawChart();
	}

}
