/* ===========================================================
 * �������̿���SimpleStock
 * ===========================================================
 *
 * Copyright (C) 2015, by ZhouJiFa.
 *
 * Project Info:  SimpleStock
 *
 * ������:		��٥�� 03121394
 * ��Ҫ������Ա����ѩ      03121323
 * 			����      03121331
 * 			��ԥ      03121326
 */

package jstockchart.test;

import jstockchart.transcation.TranscationTime;

/*
 * Ԫ���� 
 * ÿ�����󵥶�����һ�й�Ʊ����
 */
/**
 * 
 * @author zhoujifa
 */
public class StockElement extends TranscationTime {

	private String transcationTime;
	
	private double price;			//��Ʊ�۸�
	private double turnover;			//�ɽ���
	private double fluctuate;		//�۸񸡶�
	private double tansactionVolume;//�ɽ���	
	
	private String properties;		//��������
	
	private String stockCode;		//��Ʊ����
	
	/**
	 * 
	 */
	public StockElement() {
		super();
	}
	
	
	/**
	 * @return the transcationTime
	 */
	public String getTranscationTime() {
		return transcationTime;
	}


	/**
	 * @param transcationTime the transcationTime to set
	 */
	public void setTranscationTime(String transcationTime) {
		this.transcationTime = transcationTime;
	}


	/**
	 * @return the price
	 */
	public double getPrice() {
		return price;
	}


	/**
	 * @param price the price to set
	 */
	public void setPrice(double price) {
		this.price = price;
	}


	/**
	 * @return the turnover
	 */
	public double getTurnover() {
		return turnover;
	}


	/**
	 * @param turnover the turnover to set
	 */
	public void setTurnover(double turnover) {
		this.turnover = turnover;
	}


	/**
	 * @return the fluctuate
	 */
	public double getFluctuate() {
		return fluctuate;
	}


	/**
	 * @param fluctuate the fluctuate to set
	 */
	public void setFluctuate(double fluctuate) {
		this.fluctuate = fluctuate;
	}


	/**
	 * @return the tansactionVolume
	 */
	public double getTansactionVolume() {
		return tansactionVolume;
	}


	/**
	 * @param tansactionVolume the tansactionVolume to set
	 */
	public void setTansactionVolume(double tansactionVolume) {
		this.tansactionVolume = tansactionVolume;
	}


	/**
	 * @return the properties
	 */
	public String getProperties() {
		return properties;
	}


	/**
	 * @param properties the properties to set
	 */
	public void setProperties(String properties) {
		this.properties = properties;
	}


	/**
	 * @return the stockCode
	 */
	public String getStockCode() {
		return stockCode;
	}


	/**
	 * @param stockCode the stockCode to set
	 */
	public void setStockCode(String stockCode) {
		this.stockCode = stockCode;
	}


	@Override
	public String toString() {
		return "StockElement [transcationTime= " + transcationTime + " price= " + price + ", turnover= " + turnover
				+ ", fluctuate= " + fluctuate + ", tansactionVolume= "
				+ tansactionVolume + ", properties= " + properties
				+ ", stockCode= " + stockCode + " hour " + hour + " minute "+ minute + "second" + second + "]";
	}
	
	
}
