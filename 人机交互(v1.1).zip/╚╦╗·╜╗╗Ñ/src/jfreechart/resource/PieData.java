/* ===========================================================
 * �������̿���SimpleStock
 * ===========================================================
 *
 * Copyright (C) 2015, by ZhouJiFa.
 *
 * Project Info:  SimpleStock
 *
 * ������:		��٥�� 03121394
 * ��Ҫ������Ա����ѩ      03121323
 * 			����      03121331
 * 			��ԥ      03121326
 */

package jfreechart.resource;
/**
 * 
 * @author zhoujifa
 */
public class PieData implements Data {

	@SuppressWarnings("rawtypes")
	private Comparable key;
	
	private Number value;

	/**
	 * 
	 */
	public PieData() {
		// TODO Auto-generated constructor stub
	}
	
	/**
	 * @return the key
	 */
	@SuppressWarnings("rawtypes")
	public Comparable getKey() {
		return key;
	}

	/**
	 * @param key the key to set
	 */
	@SuppressWarnings("rawtypes")
	public void setKey(Comparable key) {
		this.key = key;
	}

	/**
	 * @return the value
	 */
	public Number getValue() {
		return value;
	}

	/**
	 * @param value the value to set
	 */
	public void setValue(Number value) {
		this.value = value;
	}

}
