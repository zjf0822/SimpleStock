/* ===========================================================
 * �������̿���SimpleStock
 * ===========================================================
 *
 * Copyright (C) 2015, by ZhouJiFa.
 *
 * Project Info:  SimpleStock
 *
 * ������:		��٥�� 03121394
 * ��Ҫ������Ա����ѩ      03121323
 * 			����      03121331
 * 			��ԥ      03121326
 */

package jfreechart.resource;

import java.awt.Font;
import java.util.ArrayList;
import java.util.List;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartFrame;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.StandardChartTheme;
import org.jfree.chart.axis.CategoryAxis;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.category.DefaultCategoryDataset;

/**
 * ��������ͼ
 * @author zhoujifa
 */
class Line {

	private DefaultCategoryDataset dataset;
	private StandardChartTheme standardChartTheme;

	private String XAxisName;
	private String YAxisName;
	private String titleName;

	/**
	 * 
	 */
	public Line() {
		dataset = new DefaultCategoryDataset();
	}

	/**
	 * 
	 * @param titleName
	 * @param XAxisName
	 * @param YAxisName
	 */
	public void setName(String titleName, String XAxisName, String YAxisName) {
		this.titleName = titleName;
		this.XAxisName = XAxisName;
		this.YAxisName = YAxisName;
	}

	/**
	 * 
	 * @param width
	 * @param height
	 */
	public void setSize(int width, int height) {
	}

	/**
	 * 
	 */
	public void draw() {

		JFreeChart chart = ChartFactory.createLineChart(this.titleName, // chart
																		// title
				this.XAxisName, // domain axis label
				this.YAxisName, // range axis label
				dataset, // data
				PlotOrientation.VERTICAL, // orientation
				true, // include legend
				true, // tooltips
				false // urls
				);
		CategoryPlot line = chart.getCategoryPlot();

		// customise the range axis...
		NumberAxis rangeAxis = (NumberAxis) line.getRangeAxis();
		rangeAxis.setStandardTickUnits(NumberAxis.createIntegerTickUnits());
		rangeAxis.setAutoRangeIncludesZero(true);
		rangeAxis.setUpperMargin(0.20);
		rangeAxis.setLabelAngle(Math.PI / 2.0);
		line.setRangeAxis(rangeAxis);

		setImageFont(chart);

		ChartFrame frame = new ChartFrame("���ռ۸�����", chart, true);
		frame.pack();
		frame.setVisible(true);
	}

	/**
	 * 
	 * @param theme
	 */
	public void setTheme(String theme) {
		// ����������ʽ
		standardChartTheme = new StandardChartTheme(theme);
		// ���ñ�������
		standardChartTheme.setExtraLargeFont(new Font("����", Font.BOLD, 20));
		// ����ͼ��������
		standardChartTheme.setRegularFont(new Font("����", Font.PLAIN, 15));
		// �������������
		standardChartTheme.setLargeFont(new Font("����", Font.PLAIN, 15));
	}

	/**
	 * @param value
	 * @param rowKey
	 * @param columnKey
	 */
	@SuppressWarnings("rawtypes")
	public void addValue(double value, Comparable rowKey, Comparable columnKey) {
		dataset.addValue(value, rowKey, columnKey);
	}
	
	/**
	 * @param data
	 */
	public void getDataSet(List<String[]> data) {
		for (String[] ss : data) {
			dataset.addValue(Double.valueOf(ss[0]), ss[1], ss[2]);
		}
	}

	/**
	 * @param chart
	 */
	public void setImageFont(JFreeChart chart) {
		CategoryPlot plot = (CategoryPlot) chart.getPlot();
		CategoryAxis domainAxis = plot.getDomainAxis();
		ValueAxis numberaxis = plot.getRangeAxis();

		// ���ñ�������
		chart.getTitle().setFont(new Font("����", Font.BOLD, 12));
		// ����X�������ϵ�����
		domainAxis.setTickLabelFont(new Font("����", Font.PLAIN, 11));
		// ����X ��ı�������
		domainAxis.setLabelFont(new Font("����", Font.PLAIN, 12));
		// ����Y �������ϵ�����
		numberaxis.setTickLabelFont(new Font("sans-serif", Font.PLAIN, 12));
		// ����Y ��ı�������
		numberaxis.setLabelFont(new Font("����", Font.PLAIN, 12));
		// ���õײ�����
		chart.getLegend().setItemFont(new Font("����", Font.PLAIN, 12));
	}

	/**
	 * @return list
	 */
	private List<String[]> dataList() {
		List<String[]> list = new ArrayList<String[]>();
		String[] s1 = { "10", "����", "2010" };
		String[] s2 = { "15", "����", "2011" };
		String[] s3 = { "20", "����", "2012" };
		String[] s4 = { "13", "����", "2013" };
		String[] s5 = { "17", "����", "2014" };
		String[] s6 = { "50", "����", "2015" };

		String[] z1 = { "25", "�Ϻ�", "2010" };
		String[] z2 = { "30", "�Ϻ�", "2011" };
		String[] z3 = { "5", "�Ϻ�", "2012" };
		String[] z4 = { "60", "�Ϻ�", "2013" };
		String[] z5 = { "30", "�Ϻ�", "2014" };
		String[] z6 = { "0", "�Ϻ�", "2015" };

		list.add(s1);
		list.add(s2);
		list.add(s3);
		list.add(s4);
		list.add(s5);
		list.add(s6);

		list.add(z1);
		list.add(z2);
		list.add(z3);
		list.add(z4);
		list.add(z5);
		list.add(z6);

		return list;
	}

	public static void main(String[] args) {
		Line line = new Line();
		line.getDataSet(line.dataList());
		line.setName("zhoujifa", "hello", "world");
		line.draw();

	}
}
