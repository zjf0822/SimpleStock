/* ===========================================================
 * �������̿���SimpleStock
 * ===========================================================
 *
 * Copyright (C) 2015, by ZhouJiFa.
 *
 * Project Info:  SimpleStock
 *
 * ������:		��٥�� 03121394
 * ��Ҫ������Ա����ѩ      03121323
 * 			����      03121331
 * 			��ԥ      03121326
 */

package jfreechart.resource;

/**
 * 
 * @author zhoujifa
 */
public class CategoryData implements Data {

	private double value;
	
	@SuppressWarnings("rawtypes")
	private Comparable rowKey;
	
	@SuppressWarnings("rawtypes")
	private Comparable columnKey;
	
	public CategoryData() {
		super();
	}

	/**
	 * @param value
	 * @param rowKey
	 * @param columnKey
	 */
	public CategoryData(double value,Comparable rowKey,Comparable columnKey) {
		this.value = value;
		this.rowKey = rowKey;
		this.columnKey = columnKey;
	}
	
	/**
	 * @return the value
	 */
	public double getValue() {
		return value;
	}

	/**
	 * @param value the value to set
	 */
	public void setValue(double value) {
		this.value = value;
	}

	@SuppressWarnings("rawtypes")
	public Comparable getRowKey() {
		return rowKey;
	}

	/**
	 * @param rowKey
	 */
	@SuppressWarnings("rawtypes")
	public void setRowKey(Comparable rowKey) {
		this.rowKey = rowKey;
	}

	@SuppressWarnings("rawtypes")
	public Comparable getColumnKey() {
		return columnKey;
	}

	/**
	 * @param columnKey
	 */
	@SuppressWarnings("rawtypes")
	public void setColumnKey(Comparable columnKey) {
		this.columnKey = columnKey;
	}
	
	public static void main(String[] args) {

	}
}
