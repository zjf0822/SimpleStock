/* ===========================================================
 * �������̿���SimpleStock
 * ===========================================================
 *
 * Copyright (C) 2015, by ZhouJiFa.
 *
 * Project Info:  SimpleStock
 *
 * ������:		��٥�� 03121394
 * ��Ҫ������Ա����ѩ      03121323
 * 			����      03121331
 * 			��ԥ      03121326
 */

package gui;

import gui.action.DownloadFile;
import gui.action.ForwardURL;
import gui.action.GetStockMarketData;
import gui.action.GifURL;
import gui.action.OpenExcel;
import gui.action.OpenExcelDesigner;
import gui.action.SaveAsPNG;
import gui.action.StockPriceURL;
import gui.help.OpenFlashPlayer;
import gui.help.OpenPDF;
import gui.help.OpenWord;
import gui.message.DownloadMessage;
import gui.message.Message;
import html.link.LinkURL;
import html.link.SinaFinanceNewsCollection;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.io.File;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;

import javax.swing.BoxLayout;
import javax.swing.GroupLayout;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.LayoutStyle;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;
import javax.swing.WindowConstants;
import javax.swing.filechooser.FileFilter;
import javax.swing.table.DefaultTableModel;

import jfreechart.resource.Category;
import jfreechart.resource.Pie;
import jstockchart.analysing.AnalyseFiveDaysImpl;
import jstockchart.test.TimeseriesChart;
import jxcell.data.OutputDataToExcel;

import org.htmlparser.tags.LinkTag;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;

import chrriis.dj.nativeswing.swtimpl.NativeInterface;
import db4o.privatecollection.PrivateStock;
import db4o.query.DBQueryStockName;
import db4o.stockdb.StockCode;

/**
 * ��������ΪNetBeans��ͨ���ؼ����п���ԭ�Ϳ��������ִ���Ϊ�Զ�����
 * @author zhoujifa
 */

public class FinalExercise extends JFrame {

	private WebBrowser browser;			//���������
	private WebBrowser KChart;			//K��ͼ�����
	private String filePath = "�����Ʊ����";	//�ļ�·��
	private JPanel jPanel21;			

	private String txtPath = null;		//����txt�ļ�·��
	private String excelPath = null;	//����Excel�ļ�·��
	
	private List<String> fiveDaysFilePath = new ArrayList<String>();	//���ص����ս������ݵ��ļ�·��
	private OutputDataToExcel output = new OutputDataToExcel();			//����ת����excel
	
	/**
	 * Creates new form Exercise3
	 */
	public FinalExercise() {
		initComponents();
	}

	@SuppressWarnings("unchecked")
	private void initComponents() {

        jButton5 = new JButton();
        jPanel1 = new JPanel();
        jButton1 = new JButton();
        jButton2 = new JButton();
        jButton3 = new JButton();
        jPanel4 = new JPanel();
        jPanel7 = new JPanel();
        jLabel7 = new JLabel();
        jLabel8 = new JLabel();
        jLabel9 = new JLabel();
        jLabel10 = new JLabel();
        jLabel11 = new JLabel();
        jPanel5 = new JPanel();
        jLabel1 = new JLabel();
        jLabel2 = new JLabel();
        jLabel3 = new JLabel();
        jLabel4 = new JLabel();
        jLabel5 = new JLabel();
        jLabel6 = new JLabel();
        jTabbedPane1 = new JTabbedPane();
        jPanel8 = new JPanel();
        jPanel9 = new JPanel();
        jPanel2 = new JPanel();
        jPanel3 = new JPanel();
        jPanel6 = new JPanel();
        jPanel10 = new JPanel();
        jPanel14 = new JPanel();
        jPanel19 = new JPanel();
        jPanel20 = new JPanel();
        jPanel11 = new JPanel();
        jPanel22 = new JPanel();
        jLabel12 = new JLabel();
        jLabel13 = new JLabel();
        jLabel14 = new JLabel();
        jLabel15 = new JLabel();
        jLabel16 = new JLabel();
        jLabel17 = new JLabel();
        jLabel18 = new JLabel();
        jLabel19 = new JLabel();
        jLabel20 = new JLabel();
        jLabel21 = new JLabel();
        jLabel22 = new JLabel();
        jLabel23 = new JLabel();
        jPanel23 = new JPanel();
        jPanel13 = new JPanel();
        jScrollPane1 = new JScrollPane();
        jTable1 = new JTable();
        jPanel17 = new JPanel();
        jPanel18 = new JPanel();
        jPanel16 = new JPanel();
        jPanel24 = new JPanel();
        jScrollPane2 = new JScrollPane();
        jScrollPane3 = new JScrollPane();
        jTable2 = new JTable();
        jPanel25 = new JPanel();
        jPanel26 = new JPanel();
        jButton6 = new JButton();
        jButton7 = new JButton();
        jButton8 = new JButton();
        jButton9 = new JButton();
        jPanel28 = new JPanel();
        jLabel24 = new JLabel();
        jLabel25 = new JLabel();
        jLabel26 = new JLabel();
        jLabel27 = new JLabel();
        jLabel28 = new JLabel();
        jLabel29 = new JLabel();
        jLabel30 = new JLabel();
        jLabel31 = new JLabel();
        jLabel32 = new JLabel();
        jLabel33 = new JLabel();
        jLabel34 = new JLabel();
        jLabel35 = new JLabel();
        jLabel36 = new JLabel();
        jLabel37 = new JLabel();
        jPanel29 = new JPanel();
        jPanel30 = new JPanel();
        jPanel31 = new JPanel();
        jLabel38 = new JLabel();
        jPanel21 = new JPanel();
        jTextField1 = new JTextField();
        jButton4 = new JButton();
        jPanel12 = new JPanel();
        jMenuBar1 = new JMenuBar();
        jMenu1 = new JMenu();
        jMenu4 = new JMenu();
        jMenuItem1 = new JMenuItem();
        jMenuItem2 = new JMenuItem();
        jMenu5 = new JMenu();
        jMenuItem3 = new JMenuItem();
        jMenu6 = new JMenu();
        jMenuItem5 = new JMenuItem();
        jMenuItem6 = new JMenuItem();
        jMenu2 = new JMenu();
        jMenuItem4 = new JMenuItem();
        jMenuItem7 = new JMenuItem();
        jMenu3 = new JMenu();
        jMenuItem8 = new JMenuItem();
        jMenuItem9 = new JMenuItem();
        jMenuItem10 = new JMenuItem();

        jButton5.setText("jButton5");

        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);

        jButton1.setText("��������");
        jButton1.setIcon(new javax.swing.ImageIcon(("D:/eclipse_workspace(kepler)/�˻�����/image/download.jpg")));
        jButton1.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent e) {
				jButton1ActionPerformed(e);
			}
        	
        });
        
        jButton2.setText("�����ղ�");
        jButton2.setIcon(new javax.swing.ImageIcon(("D:/eclipse_workspace(kepler)/�˻�����/image/save.png")));
        jButton2.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent e) {
				jButton2ActionPerformed(e);
			}
        	
        });
        
        jButton3.setText("���˲ƾ�");
        jButton3.setIcon(new javax.swing.ImageIcon(("D:/eclipse_workspace(kepler)/�˻�����/image/sina.jpg")));
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });
        
        GroupLayout jPanel1Layout = new GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jButton1)
                .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jButton2)
                .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jButton3)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton1)
                    .addComponent(jButton2)
                    .addComponent(jButton3))
                .addGap(0, 10, Short.MAX_VALUE))
        );

        jLabel7.setText("���ս�������");

        jLabel8.setText(getSystemDate());

        jLabel9.setText(getSystemWeekOfDate());

        jLabel10.setText("��ǰ����ʱ��");

        jLabel11.setText("--:--:--");

        GroupLayout jPanel7Layout = new GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel7Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel7)
                    .addComponent(jLabel8)
                    .addComponent(jLabel9)
                    .addComponent(jLabel10)
                    .addComponent(jLabel11))
                .addContainerGap(GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel7, GroupLayout.PREFERRED_SIZE, 57, GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel8)
                .addGap(39, 39, 39)
                .addComponent(jLabel9)
                .addGap(41, 41, 41)
                .addComponent(jLabel10)
                .addGap(36, 36, 36)
                .addComponent(jLabel11)
                .addContainerGap(20, Short.MAX_VALUE))
        );

        jLabel1.setText("��ָ֤��");

        jLabel2.setText("--");

        jLabel3.setText("--");

        jLabel4.setText("��֤��ָ");

        jLabel5.setText("--");

        jLabel6.setText("--");

        GroupLayout jPanel5Layout = new GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel5Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel1)
                    .addComponent(jLabel2)
                    .addComponent(jLabel3)
                    .addComponent(jLabel4)
                    .addComponent(jLabel5)
                    .addComponent(jLabel6))
                .addContainerGap(GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addGap(18, 18, 18)
                .addComponent(jLabel2)
                .addGap(14, 14, 14)
                .addComponent(jLabel3)
                .addGap(18, 18, 18)
                .addComponent(jLabel4)
                .addGap(18, 18, 18)
                .addComponent(jLabel5)
                .addGap(18, 18, 18)
                .addComponent(jLabel6)
                .addContainerGap(25, Short.MAX_VALUE))
        );

        jPanel8.setLayout(new BoxLayout(jPanel8, BoxLayout.Y_AXIS));

        jTabbedPane1.addTab("������Ѷ", jPanel8);

        jPanel2.setLayout(new FlowLayout());

        jPanel3.setLayout(new FlowLayout());

        jPanel6.setLayout(new FlowLayout());

        jPanel10.setLayout(new FlowLayout());

        jPanel14.setLayout(new FlowLayout());

        jPanel19.setLayout(new FlowLayout());

        jPanel20.setLayout(new FlowLayout());

        GroupLayout jPanel9Layout = new GroupLayout(jPanel9);
        jPanel9.setLayout(jPanel9Layout);
        jPanel9Layout.setHorizontalGroup(
            jPanel9Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addComponent(jPanel14, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(jPanel9Layout.createSequentialGroup()
                .addGroup(jPanel9Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel9Layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(jPanel9Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                            .addComponent(jPanel2, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jPanel6, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jPanel10, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jPanel3, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jPanel19, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                    .addComponent(jPanel20, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        jPanel9Layout.setVerticalGroup(
            jPanel9Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addGroup(jPanel9Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel2, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jPanel3, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jPanel6, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jPanel10, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jPanel19, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jPanel14, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jPanel20, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
                .addContainerGap(16, Short.MAX_VALUE))
        );
        

        jTabbedPane1.addTab("��ַ����", jPanel9);

        jPanel16.setLayout(new java.awt.BorderLayout());
        jTabbedPane1.addTab("���˲ƾ�", jPanel16);
        
        jPanel11.setLayout(new java.awt.BorderLayout());

        jLabel12.setText("��Ʊ����");

        jLabel13.setText("��ǰ�۸�");

        jLabel14.setText("�۸񸡶�");

        jLabel15.setText("�ǵ���");

        jLabel16.setText("�ɽ���");

        jLabel17.setText("�ɽ���");

        jLabel18.setText("--");

        jLabel19.setText("--");

        jLabel20.setText("--");

        jLabel21.setText("--");

        jLabel22.setText("--");

        jLabel23.setText("--");

        GroupLayout jPanel22Layout = new GroupLayout(jPanel22);
        jPanel22.setLayout(jPanel22Layout);
        jPanel22Layout.setHorizontalGroup(
            jPanel22Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addGroup(jPanel22Layout.createSequentialGroup()
                .addGap(44, 44, 44)
                .addGroup(jPanel22Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel12)
                    .addComponent(jLabel18))
                .addGap(89, 89, 89)
                .addGroup(jPanel22Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel13)
                    .addComponent(jLabel19))
                .addGap(83, 83, 83)
                .addGroup(jPanel22Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel14)
                    .addComponent(jLabel20))
                .addGap(82, 82, 82)
                .addGroup(jPanel22Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel15)
                    .addComponent(jLabel21))
                .addGap(80, 80, 80)
                .addGroup(jPanel22Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel16)
                    .addComponent(jLabel22))
                .addGap(76, 76, 76)
                .addGroup(jPanel22Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel23)
                    .addComponent(jLabel17))
                .addContainerGap(94, Short.MAX_VALUE))
        );
        jPanel22Layout.setVerticalGroup(
            jPanel22Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addGroup(jPanel22Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel22Layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel12)
                    .addComponent(jLabel13)
                    .addComponent(jLabel14)
                    .addComponent(jLabel15)
                    .addComponent(jLabel16)
                    .addComponent(jLabel17))
                .addGap(27, 27, 27)
                .addGroup(jPanel22Layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel18)
                    .addComponent(jLabel19)
                    .addComponent(jLabel20)
                    .addComponent(jLabel21)
                    .addComponent(jLabel22)
                    .addComponent(jLabel23))
                .addContainerGap(33, Short.MAX_VALUE))
        );

        jPanel11.add(jPanel22, java.awt.BorderLayout.PAGE_START);

        jPanel23.setLayout(new java.awt.BorderLayout());
        jPanel11.add(jPanel23, java.awt.BorderLayout.CENTER);

        jTabbedPane1.addTab("��Ʊ��ͼ", jPanel11);

        jPanel25.setLayout(new java.awt.BorderLayout());

        jButton6.setText("ʵʱKͼ");
        jButton6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton6ActionPerformed(evt);
            }
        });

        jButton7.setText("��K��ͼ");
        jButton7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton7ActionPerformed(evt);
            }
        });

        jButton8.setText("��K��ͼ");
        jButton8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton8ActionPerformed(evt);
            }
        });

        jButton9.setText("��K��ͼ");
        jButton9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton9ActionPerformed(evt);
            }
        });

        GroupLayout jPanel26Layout = new GroupLayout(jPanel26);
        jPanel26.setLayout(jPanel26Layout);
        jPanel26Layout.setHorizontalGroup(
            jPanel26Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addGroup(jPanel26Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel26Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                    .addComponent(jButton6)
                    .addComponent(jButton7)
                    .addComponent(jButton8)
                    .addComponent(jButton9))
                .addContainerGap(GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel26Layout.setVerticalGroup(
            jPanel26Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addGroup(jPanel26Layout.createSequentialGroup()
                .addGap(49, 49, 49)
                .addComponent(jButton6)
                .addGap(45, 45, 45)
                .addComponent(jButton7)
                .addGap(49, 49, 49)
                .addComponent(jButton8)
                .addGap(55, 55, 55)
                .addComponent(jButton9)
                .addContainerGap(258, Short.MAX_VALUE))
        );

        jPanel25.add(jPanel26, java.awt.BorderLayout.LINE_END);

        jLabel24.setText("��Ʊ����");

        jLabel25.setText("���룺--");

        jLabel26.setText("��Ʊ����");

        jLabel27.setText("���ƣ�--");

        jLabel28.setText("��ǰ�۸�");

        jLabel29.setText("�۸�--");

        jLabel30.setText("��ǰ�Ƿ�");

        jLabel31.setText("���ȣ�--");

        jLabel32.setText("�ǵ���");

        jLabel33.setText("�ǵ��ʣ�--");

        jLabel34.setText("�ɽ���");

        jLabel35.setText("�������֣���--");

        jLabel36.setText("�ɽ���");

        jLabel37.setText("������Ԫ����--");

        GroupLayout jPanel28Layout = new GroupLayout(jPanel28);
        jPanel28.setLayout(jPanel28Layout);
        jPanel28Layout.setHorizontalGroup(
            jPanel28Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addGroup(jPanel28Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel28Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel24)
                    .addComponent(jLabel25)
                    .addComponent(jLabel26)
                    .addComponent(jLabel27)
                    .addComponent(jLabel28)
                    .addComponent(jLabel29)
                    .addComponent(jLabel30)
                    .addComponent(jLabel31)
                    .addComponent(jLabel32)
                    .addComponent(jLabel33)
                    .addComponent(jLabel34)
                    .addComponent(jLabel35)
                    .addComponent(jLabel36)
                    .addComponent(jLabel37))
                .addContainerGap(42, Short.MAX_VALUE))
        );
        jPanel28Layout.setVerticalGroup(
            jPanel28Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addGroup(jPanel28Layout.createSequentialGroup()
                .addGap(34, 34, 34)
                .addComponent(jLabel24)
                .addGap(18, 18, 18)
                .addComponent(jLabel25)
                .addGap(18, 18, 18)
                .addComponent(jLabel26)
                .addGap(18, 18, 18)
                .addComponent(jLabel27)
                .addGap(18, 18, 18)
                .addComponent(jLabel28)
                .addGap(18, 18, 18)
                .addComponent(jLabel29)
                .addGap(18, 18, 18)
                .addComponent(jLabel30)
                .addGap(18, 18, 18)
                .addComponent(jLabel31)
                .addGap(18, 18, 18)
                .addComponent(jLabel32)
                .addGap(18, 18, 18)
                .addComponent(jLabel33)
                .addGap(18, 18, 18)
                .addComponent(jLabel34)
                .addGap(18, 18, 18)
                .addComponent(jLabel35)
                .addGap(18, 18, 18)
                .addComponent(jLabel36)
                .addGap(18, 18, 18)
                .addComponent(jLabel37)
                .addContainerGap(70, Short.MAX_VALUE))
        );

        jPanel25.add(jPanel28, java.awt.BorderLayout.LINE_START);

        jPanel29.setLayout(new java.awt.BorderLayout());

        jLabel38.setFont(new java.awt.Font("����", 0, 24)); // NOI18N
        jLabel38.setText("ʵʱKͼ");

        GroupLayout jPanel30Layout = new GroupLayout(jPanel30);
        jPanel30.setLayout(jPanel30Layout);
        jPanel30Layout.setHorizontalGroup(
            jPanel30Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addGroup(GroupLayout.Alignment.TRAILING, jPanel30Layout.createSequentialGroup()
                .addContainerGap(266, Short.MAX_VALUE)
                .addComponent(jLabel38, GroupLayout.PREFERRED_SIZE, 94, GroupLayout.PREFERRED_SIZE)
                .addGap(257, 257, 257))
        );
        jPanel30Layout.setVerticalGroup(
            jPanel30Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addGroup(GroupLayout.Alignment.TRAILING, jPanel30Layout.createSequentialGroup()
                .addContainerGap(31, Short.MAX_VALUE)
                .addComponent(jLabel38, GroupLayout.PREFERRED_SIZE, 45, GroupLayout.PREFERRED_SIZE)
                .addGap(24, 24, 24))
        );

        jPanel29.add(jPanel30, java.awt.BorderLayout.PAGE_START);

        jPanel25.add(jPanel29, java.awt.BorderLayout.CENTER);

        jTabbedPane1.addTab("ʵʱ����", jPanel25);
        
        String title [] = {"����", "���̼�", "���̼�", "��߼�", "��ͼ�", "������"};
        Object object[][] = new Object[5][6];

        jTable1.setModel(new DefaultTableModel(object,title) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false
            };

            @Override
			public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(jTable1);

        jPanel17.setLayout(new BorderLayout());

        jPanel18.setLayout(new BorderLayout());

        jScrollPane3.setViewportView(jPanel31);
        jPanel31.add(jPanel17);
        jPanel31.add(jPanel18);
        
        GroupLayout jPanel13Layout = new GroupLayout(jPanel13);
        jPanel13.setLayout(jPanel13Layout);
        jPanel13Layout.setHorizontalGroup(
            jPanel13Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane1, GroupLayout.DEFAULT_SIZE, 836, Short.MAX_VALUE)
            .addComponent(jScrollPane3, GroupLayout.DEFAULT_SIZE, 836, Short.MAX_VALUE)
        );
        jPanel13Layout.setVerticalGroup(
            jPanel13Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addGroup(jPanel13Layout.createSequentialGroup()
                .addComponent(jScrollPane1, GroupLayout.PREFERRED_SIZE, 108, GroupLayout.PREFERRED_SIZE)
                .addComponent(jScrollPane3, GroupLayout.PREFERRED_SIZE, 475, GroupLayout.PREFERRED_SIZE))
        );

        jTabbedPane1.addTab("���շ���", jPanel13);

        jPanel24.setLayout(new java.awt.BorderLayout());

        Object [][] saveStock = getPrivateStock();
        String title2[] = {"��Ʊ����","���ƴ���", "���¼۸�", "�ǵ�����"};
        jTable2.setModel(new DefaultTableModel(saveStock,title2) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.String.class ,java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false
            };

            @Override
			public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            @Override
			public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane2.setViewportView(jTable2);

        jPanel24.add(jScrollPane2, java.awt.BorderLayout.CENTER);

        jTabbedPane1.addTab("�����ղ�", jPanel24);

        jTextField1.setText("�����Ʊ����");
        jTextField1.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
			public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTextField1MouseClicked(evt);
            }
        });
        jPanel21.add(jTextField1);

//        jButton4.setText("��ѯ");
        jButton4.setIcon(new javax.swing.ImageIcon(("D:/eclipse_workspace(kepler)/�˻�����/image/search.png")));
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });
        jPanel21.add(jButton4);

        GroupLayout jPanel4Layout = new GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGroup(jPanel4Layout.createParallelGroup(GroupLayout.Alignment.TRAILING, false)
                    .addComponent(jPanel5, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel7, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel21, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jTabbedPane1))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addComponent(jPanel21, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jPanel5, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jPanel7, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
            .addComponent(jTabbedPane1)
        );

        GroupLayout jPanel12Layout = new GroupLayout(jPanel12);
        jPanel12.setLayout(jPanel12Layout);
        jPanel12Layout.setHorizontalGroup(
            jPanel12Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        jPanel12Layout.setVerticalGroup(
            jPanel12Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );

        jMenu1.setText("�ļ�(F)");

        jMenu4.setText("�����ļ�");

        jMenuItem1.setText("����.txt�ļ�");
        jMenuItem1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem1ActionPerformed(evt);
            }
        });
        jMenu4.add(jMenuItem1);

        jMenuItem2.setText("����.xls�ļ�");
        jMenuItem2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem2ActionPerformed(evt);
            }
        });
        jMenu4.add(jMenuItem2);

        jMenu1.add(jMenu4);

        jMenu5.setText("����ͼƬ");

        jMenuItem3.setText(".PNG�ļ�");
        jMenuItem3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem3ActionPerformed(evt);
            }
        });
        jMenu5.add(jMenuItem3);

        jMenu1.add(jMenu5);

        jMenu6.setText("��������");

        jMenuItem5.setText("���� .txt����");
        jMenuItem5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem5ActionPerformed(evt);
            }
        });
        jMenu6.add(jMenuItem5);

        jMenuItem6.setText("���� .xls����");
        jMenuItem6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem6ActionPerformed(evt);
            }
        });
        jMenu6.add(jMenuItem6);

        jMenu1.add(jMenu6);

        jMenuBar1.add(jMenu1);

        jMenu2.setText("Excel(E)");

        jMenuItem4.setText("�򿪱���Excel");
        jMenuItem4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem4ActionPerformed(evt);
            }
        });
        jMenu2.add(jMenuItem4);

        jMenuItem7.setText("���Դ�Excel");
        jMenuItem7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem7ActionPerformed(evt);
            }
        });
        jMenu2.add(jMenuItem7);

        jMenuBar1.add(jMenu2);

        jMenu3.setText("����(H)");

        jMenuItem8.setText("Word�ĵ�����");
        jMenuItem8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem8ActionPerformed(evt);
            }
        });
        jMenu3.add(jMenuItem8);

        jMenuItem9.setText("PDF�ĵ�����");
        jMenuItem9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem9ActionPerformed(evt);
            }
        });
        jMenu3.add(jMenuItem9);

        jMenuItem10.setText("��Ƶ����");
        jMenuItem10.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem10ActionPerformed(evt);
            }
        });
        jMenu3.add(jMenuItem10);

        jMenuBar1.add(jMenu3);

        setJMenuBar(jMenuBar1);

        GroupLayout layout = new GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jPanel4, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel4, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
        
        webGuide();
		browser();
        KChart();
		newsPanel();
		new CurrentTime().start();
		new Thread(new MarketPrice()).start();
		
    }       

	/**
	 * ���ӹ�Ʊ�ղص��¼�
	 * @param e
	 */
	protected void jButton2ActionPerformed(ActionEvent e) {
		PrivateStock stocks = new PrivateStock();
		if(jTextField1.getText() == "�����Ʊ����") {
			return ;
		}
		String code = jTextField1.getText().substring(3);
		List<StockCode> list = stocks.query();
		DBQueryStockName query = new DBQueryStockName();
		String name = query.getStockName(code);
		StockCode stock = new StockCode();
		stock.setStockCode(code);
		stock.setStockName(name);
		if(list.contains(stock) != true) {
			stocks.save(code, name);
		}
		
		/*
		 * refresh the table!!!
		 */
		Object [][] saveStock = getPrivateStock();
        String title2[] = {"��Ʊ����","���ƴ���", "���¼۸�", "�ǵ�����"};
		jTable2.setModel(new DefaultTableModel(saveStock, title2));
	}

	/**
	 * @param e
	 * download data
	 */
	private void jButton1ActionPerformed(ActionEvent e) {
		
		try {
			DownloadTxtDialog dialog1 = new DownloadTxtDialog();
			dialog1.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			dialog1.setVisible(true);
			
			txtPath = dialog1.getDownloadPath();
			
			System.out.println("download txtPath *** " + txtPath);
		} catch (Exception e1) {
			e1.printStackTrace();
		}
	}

	/**
	 * ������������ȡ��K��ͼ
	 * @param evt
	 */
	private void jButton9ActionPerformed(ActionEvent evt) {
		String code = jTextField1.getText().substring(3);
		boolean ret = serach(code);
		if (ret == true) {
			GifURL gifUrl = new GifURL(code);
			KChart.forward(gifUrl.getMonthUrl());
			jLabel38.setText("��K��ͼ"); 
		} else {
			KChart.forward("http://image.sinajs.cn/newchart/monthly/n/sh000001.gif");
			jLabel38.setText("��K��ͼ"); 
		}
	}

	/**
	 * ���������ȡ��K��ͼ
	 * @param evt
	 */
	private void jButton8ActionPerformed(ActionEvent evt) {
		String code = jTextField1.getText().substring(3);
		boolean ret = serach(code);
		if (ret == true) {
			GifURL gifUrl = new GifURL(code);
			KChart.forward(gifUrl.getWeekUrl());
			jLabel38.setText("��K��ͼ"); 
		} else {
			KChart.forward("http://image.sinajs.cn/newchart/weekly/n/sh000001.gif");
			jLabel38.setText("��K��ͼ");
		}
	}

	/**
	 * �������ת�����˲ƾ�����ҳ
	 * @param evt
	 */
	private void jButton3ActionPerformed(ActionEvent evt) {
		browser.forward("http://finance.sina.com.cn/stock/");
	}

	/**
	 * ���������ȡ��K��ͼ
	 * @param evt
	 */
	private void jButton7ActionPerformed(ActionEvent evt) {
		String code = jTextField1.getText().substring(3);
		boolean ret = serach(code);
		if (ret == true) {
			GifURL gifUrl = new GifURL(code);
			KChart.forward(gifUrl.getDailyUrl());
			jLabel38.setText("��K��ͼ"); 
		} else {
			KChart.forward("http://image.sinajs.cn/newchart/daily/n/sh000001.gif");
			jLabel38.setText("��K��ͼ"); 
		}
	}

	/**
	 * ���������ȡʵʱ��K��ͼ
	 * @param evt
	 */
	private void jButton6ActionPerformed(ActionEvent evt) {
		String code = jTextField1.getText().substring(3);
		boolean ret = serach(code);
		if (ret == true) {
			GifURL gifUrl = new GifURL(code);
			KChart.forward(gifUrl.getMinUrl());
			jLabel38.setText("ʵʱKͼ");
		} else {
			KChart.forward("http://image.sinajs.cn/newchart/min/n/sh000001.gif");
			jLabel38.setText("ʵʱKͼ");
		}
	}

	/**
	 * �������¼����������򴥷��¼�
	 * @param evt
	 */
	private void jTextField1MouseClicked(MouseEvent evt) {
		jTextField1.setText("����:");
	}

	/**
	 * ����ʵʱ���ݣ�
	 * @param code
	 */
	private void requestAction(String code) {
		ForwardURL forwardUrl = new ForwardURL(code);
		browser.forward(forwardUrl.forwordUrl());
		GifURL gifUrl = new GifURL(code);
		KChart.forward(gifUrl.getMinUrl());
		
		String txt = yesterdayChart(code);
					
		excelPath = txt.substring(0, txt.length() - 3) + "xls";
		output.setFilePath(txt, excelPath);
		output.output();
		
		fiveCategoryDraw();
		fivePieDraw();
		
		GetStockMarketData data = new GetStockMarketData();
		data.request(new StockPriceURL(code).getUrl());
		jLabel18.setText(data.getStockName());
		
		//�������֣�
		jLabel19.setText(data.getPrice());
		jLabel20.setText(data.getStockIndex());
		jLabel21.setText(data.getFluctuate() + "%");
		
		jLabel22.setText(data.getTurnover() + "(��)");
		jLabel23.setText(data.getTansactionVolume() + "(��Ԫ)");
		
		jLabel25.setText("���룺" + code);
		jLabel27.setText("���ƣ�" + data.getStockName());
		jLabel29.setText("�۸�" + data.getPrice());
		jLabel31.setText("���ȣ�" + data.getStockIndex());
		jLabel33.setText("�ǵ��ʣ�" + data.getFluctuate() + "%");
		jLabel35.setText("�������֣���" + data.getTurnover());
		jLabel37.setText("��������Ԫ����" + data.getTansactionVolume());
		
		//����������ɫ
		if(Double.valueOf(data.getStockIndex()) > 0 ) {
			jLabel19.setForeground(new java.awt.Color(204, 0, 0));
			jLabel20.setForeground(new java.awt.Color(204, 0, 0));
			jLabel21.setForeground(new java.awt.Color(204, 0, 0));
			
			jLabel29.setForeground(new java.awt.Color(204, 0, 0));
			jLabel31.setForeground(new java.awt.Color(204, 0, 0));
			jLabel33.setForeground(new java.awt.Color(204, 0, 0));
		} else if(Double.valueOf(data.getStockIndex()) < 0 ){
			jLabel19.setForeground(new java.awt.Color(0, 204, 0));
			jLabel20.setForeground(new java.awt.Color(0, 204, 0));
			jLabel21.setForeground(new java.awt.Color(0, 204, 0));
			
			jLabel29.setForeground(new java.awt.Color(0, 204, 0));
			jLabel31.setForeground(new java.awt.Color(0, 204, 0));
			jLabel33.setForeground(new java.awt.Color(0, 204, 0));
		} else {
			jLabel19.setForeground(new java.awt.Color(0, 0, 204));
			jLabel20.setForeground(new java.awt.Color(0, 0, 204));
			jLabel21.setForeground(new java.awt.Color(0, 0, 204));
			
			jLabel29.setForeground(new java.awt.Color(0, 0, 204));
			jLabel31.setForeground(new java.awt.Color(0, 0, 204));
			jLabel33.setForeground(new java.awt.Color(0, 0, 204));
			
			jLabel19.setText("ͣ��");
			jLabel29.setText("�۸�" + "ͣ��");
		}
		
		//�������ս��׵ı���
		String title [] = {"����", "���̼�", "���̼�", "��߼�", "��ͼ�", "������"};
        Object object[][] = getFiveDaysAnalyse();
		jTable1.setModel(new DefaultTableModel(object, title));
	}
	
	/**
	 * �ж���������Ƿ���Ч
	 * @param evt
	 */
	private void jButton4ActionPerformed(ActionEvent evt) {
		String code = jTextField1.getText().substring(3);
		boolean ret = serach(code);

		if (ret == true) {
			requestAction(code);
		} else {
			try {
				Message dialog = new Message();
				dialog.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
				dialog.setVisible(true);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

	/**
	 * 
	 * @param stockCode
	 * @return
	 */
	private String yesterdayChart(String stockCode) {
		DownloadFile download = new DownloadFile();
		if(stockCode.charAt(0) >= 54) { //char '6' = 54
			stockCode = "sh" + stockCode;
		} else {
			stockCode = "sz" + stockCode;
		}
		download.downloadNet(Week.yesterday(), stockCode);
		draw(download.getFilePath());
		
		return download.getFilePath();
	}
	
	/**
	 * 
	 * @param filePath
	 */
	private void draw(String filePath) {
		if (filePath.endsWith(".txt") || filePath.endsWith(".xls")
				|| filePath.endsWith(".xlsx")) {
			TimeseriesChart chart = new TimeseriesChart(filePath);
			DBQueryStockName query = new DBQueryStockName();
			
			String input = "600000";
			if(filePath.endsWith(".txt") || filePath.endsWith(".xls")) {
				input = filePath.substring(filePath.length()-10, filePath.length()-4);
			} else {
				input = filePath.substring(filePath.length()-10, filePath.length()-5);
			}
			chart.setStockName(query.getStockName(input));
			JFreeChart plot = chart.drawChart();
			JPanel panel = new ChartPanel(plot);
			if (jPanel23.getComponentCount() != 0) {
				jPanel23.removeAll();
			}
			jPanel23.add(panel);
			jPanel23.validate();
		}
	}

	/**
	 * 
	 * @param evt
	 */
	private void jMenuItem1ActionPerformed(ActionEvent evt) {
		filePath = fileTxtChooser();
		draw(filePath);
		
		String str = filePath.substring(filePath.length()-10, filePath.length()-4);
		requestAction(str);
		System.out.println(" �����ļ���ת��Ϣ " +str + " ****** ");
	}

	/**
	 * 
	 * @param evt
	 */
	private void jMenuItem2ActionPerformed(ActionEvent evt) {
		filePath = fileXlsChooser();
		draw(filePath);
		
		String str = filePath.substring(filePath.length()-10, filePath.length()-4);
		requestAction(str);
		System.out.println(" �����ļ���ת��Ϣ " +str + " ****** ");
	}

	/**
	 * 
	 * @param str
	 * @param filePath
	 */
	private void savepng(String str,String filePath) {
		TimeseriesChart chart = new TimeseriesChart(filePath);
		DBQueryStockName query = new DBQueryStockName();
		
		String input = "600000";
		if(filePath.endsWith(".txt") || filePath.endsWith(".xls")) {
			input = filePath.substring(filePath.length()-10, filePath.length()-4);
		} else {
			input = filePath.substring(filePath.length()-10, filePath.length()-5);
		}
		chart.setStockName(query.getStockName(input));
		JFreeChart plot = chart.drawChart();
		
		System.out.println("PictureSavePath *** " + str + "  filepath " + filePath );
		String strs[] = str.split("\\\\");
		str = "";
		for(int i = 0;i < strs.length;i++) {
			str = str + strs[i] + "/";
		}
		SaveAsPNG png = new SaveAsPNG(str+"/stock.png", plot);
		png.savePNG();
		System.out.println("PictureSavePath" + str + "stock.png");
	}
	
	/**
	 * ����ͼƬ
	 * @param evt
	 */
	private void jMenuItem3ActionPerformed(ActionEvent evt) {
		String str = filePngChooser();
		//���ص��ļ���·����׺������Ҫ��
		if (filePath.endsWith(".txt") || filePath.endsWith(".xls")
				|| filePath.endsWith(".xlsx")) {
			savepng(str,filePath);
		} 
		//����������ڵ�K��ͼͼƬ
		else {
			savepng(str,fiveDaysFilePath.get(4));
		}
	}
	
	/**
	 * ����txt�ļ����¼�
	 * @param evt
	 */
	private void jMenuItem5ActionPerformed(ActionEvent evt) {
		
//		if(jTextField1.getText() == "�����Ʊ����") {
//			DownloadMessage dialog = new DownloadMessage("���д������ݿ�ʼ����");
//			dialog.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
//			dialog.setVisible(true);
//		} else {
			
			
			try {
				DownloadTxtDialog dialog1 = new DownloadTxtDialog();
				dialog1.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
				dialog1.setVisible(true);
			} catch (Exception e) {
				e.printStackTrace();
			}
			
//			DownloadMessage dialog = new DownloadMessage("�ù����½��׿�ʼ����");
//			dialog.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
//			dialog.setVisible(true);

//		}
	}

	/**
	 * ����xls�ļ����¼�
	 * @param evt
	 */
	private void jMenuItem6ActionPerformed(ActionEvent evt) {
//		if(jTextField1.getText() == "�����Ʊ����") {
//			DownloadMessage dialog = new DownloadMessage("���д������ݿ�ʼ����");
//			dialog.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
//			dialog.setVisible(true);
//		} else {
						
			try {
				DownloadXlsDialog dialog1 = new DownloadXlsDialog();
				dialog1.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
				dialog1.setVisible(true);
				excelPath = dialog1.getDownloadPath();
			} catch (Exception e) {
				e.printStackTrace();
			}
			
//			DownloadMessage dialog = new DownloadMessage("�ù����½��׿�ʼ����");
//			dialog.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
//			dialog.setVisible(true);

//		}
	}

	/**
	 * �򿪱���Excel�ļ�
	 * @param evt
	 */
	private void jMenuItem4ActionPerformed(ActionEvent evt) {
		if(excelPath != null) {
			OpenExcel.openExcel(excelPath);
		} else {
			OpenExcel.openExcel();
		}
	}

	/**
	 * �������Դ���Excel����
	 * @param evt
	 */
	private void jMenuItem7ActionPerformed(ActionEvent evt) {
		SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				OpenExcelDesigner designer = new OpenExcelDesigner();
				designer.openExcel(output.getView());
			}
		});
		SwingUtilities.updateComponentTreeUI(getContentPane());
	}

	/**
	 * ��word�ĵ�����
	 * @param evt
	 */
	private void jMenuItem8ActionPerformed(ActionEvent evt) {
		OpenWord word = new OpenWord("D:/eclipse_workspace(kepler)/�˻�����/help/�����ĵ�.doc");
		word.open();
	}

	/**
	 * ��pdf�ĵ�����
	 * @param evt
	 */
	private void jMenuItem9ActionPerformed(ActionEvent evt) {
		OpenPDF pdf = new OpenPDF("D:/eclipse_workspace(kepler)/�˻�����/help/�����ĵ�.pdf");
		pdf.open();
	}

	/**
	 * ����Ƶ����
	 * @param evt
	 */
	private void jMenuItem10ActionPerformed(ActionEvent evt) {
		OpenFlashPlayer player = new OpenFlashPlayer("D:\\86.avi");
		player.play();
	}

	/**
	 * �������յ�����ͼ
	 */
	private void fiveCategoryDraw() {
		//��������������
		Category c = new Category();
		c.setName("���ս������", "ʱ��", "���׼۸�䶯");
		//��ȡ��Ʊ����
		String code = jTextField1.getText().substring(3);
		//���ؽ�����ж��Ƿ��иù�Ʊ
		boolean ret = serach(code);
		Object obj [][] = new Object[5][6];
		List<String> fiveFilePaths = new ArrayList<String>();
		
		//��֤��ʼ���϶�����ĳһֻ��Ʊ��Ϣ
		if(ret != true) {
			code = "600000";
		}
		//���ҹ�Ʊ����
		DBQueryStockName query = new DBQueryStockName();
		String name = query.getStockName(code);
		//���ù�Ʊ
		if(code.charAt(0) >= 54) { //char '6' = 54
			code = "sh" + code;
		} else {
			code = "sz" + code;
		}
		
		//��ȡһ�ܵ�����
		Week weeks = new Week();
		List<String> list = weeks.getDateList();
		//�����ļ�
		DownloadFile download = new DownloadFile();
		
		//���ļ��ı���list���Ƴ�list��
		for(int i = 0;i < fiveDaysFilePath.size();i++) {
			fiveDaysFilePath.remove(fiveDaysFilePath.size()-1);
		}
		
		//��ȡurl�������ļ�
		for(String day : list) {
			download.downloadNet(day, code);
			fiveFilePaths.add(download.getFilePath());
			fiveDaysFilePath.add(download.getFilePath());
		}
		//�������յ�����
		AnalyseFiveDaysImpl a = new AnalyseFiveDaysImpl(fiveFilePaths);
		a.analyse();

		//������ݣ���ͼ
		for(int i = 0;i < 5;i++) {
			c.addValue(a.getFiveDaysAnalysis().get(i).getTranscationInfo().getEndValue(), name, list.get(i));
		}
		
		//��ͼ
		JFreeChart plot = c.getChart();
		JPanel panel = new ChartPanel(plot);
		if (jPanel17.getComponentCount() != 0) {
			jPanel17.removeAll();
		}
		jPanel17.add(panel,BorderLayout.CENTER);
		jPanel17.validate();
	}
	
	private void fivePieDraw() {
		Pie pie = new Pie();
		pie.setTitleName("���ս��������ֲ����");
		
		String code = jTextField1.getText().substring(3);
		boolean ret = serach(code);
		Object obj [][] = new Object[5][6];
		List<String> fiveFilePaths = new ArrayList<String>();
		
		//��֤��ʼ���϶�����ĳһֻ��Ʊ��Ϣ
		if(ret != true) {
			code = "600000";
		}
		//��ȡ��Ʊ����
		DBQueryStockName query = new DBQueryStockName();
		String name = query.getStockName(code);
		
		//���ڳ�ָ����֤��ָ
		if(code.charAt(0) >= 54) { //char '6' = 54
			code = "sh" + code;
		} else {
			code = "sz" + code;
		}
		
		//��ȡһ�ܵ�����list
		Week weeks = new Week();
		List<String> list = weeks.getDateList();
		//������������
		AnalyseFiveDaysImpl a = new AnalyseFiveDaysImpl(fiveDaysFilePath);
		a.analyse();
		
		//������ݣ���ͼ
//		for(int i = 0;i < fiveDaysFilePath.size();i++) {
		for(int i = 0;i < 5;i++) {
			int volume = a.getFiveDaysAnalysis().get(i).getTranscationInfo().getTranscationVolume().getTotalTranscationVolume() / 10000;
			if(volume < 0) {
				volume *= -1;
			}
			pie.addValue(list.get(i), volume);
		}
		
		//��ͼ
		JFreeChart plot = pie.getChart();
		JPanel panel = new ChartPanel(plot);
		if (jPanel18.getComponentCount() != 0) {
			jPanel18.removeAll();
		}
		jPanel18.add(panel,BorderLayout.CENTER);
		jPanel18.validate();
	}
	
	/**
	 * ���շ���
	 * @return
	 */
	private Object[][] getFiveDaysAnalyse() {
		
		String code = jTextField1.getText().substring(3);
		boolean ret = serach(code);
		Object obj [][] = new Object[5][6];
		List<String> fiveFilePaths = new ArrayList<String>();
		
		//��֤��ʼ���϶�����ĳһֻ��Ʊ��Ϣ
		if(ret != true) {
			code = "600000";
		}
		//���ڳ�ָ����֤��ָ
		if(code.charAt(0) >= 54) { //char '6' = 54
			code = "sh" + code;
		} else {
			code = "sz" + code;
		}
		
		//һ�ܵ�����list
		Week weeks = new Week();
		List<String> list = weeks.getDateList();
		
		//���շ���
		AnalyseFiveDaysImpl analyse = new AnalyseFiveDaysImpl(fiveDaysFilePath);
		analyse.analyse();
		
		//������ݣ�����table
//		for(int i = 0;i < fiveDaysFilePath.size();i++) {
		for(int i = 0;i < 5;i++) {
			obj[i][0] = list.get(i);
			obj[i][1] = analyse.getFiveDaysAnalysis().get(i).getTranscationInfo().getBeginValue();
			if(obj[i][1].equals(0)) {
				obj[i][1] = "ͣ��";
			}
			obj[i][2] = analyse.getFiveDaysAnalysis().get(i).getTranscationInfo().getEndValue();
			if(obj[i][2].equals(0)) {
				obj[i][2] = "ͣ��";
			}
			obj[i][3] = analyse.getFiveDaysAnalysis().get(i).getTranscationInfo().getMaxValue();
			if(obj[i][3].equals(0)) {
				obj[i][3] = "ͣ��";
			}
			obj[i][4] = analyse.getFiveDaysAnalysis().get(i).getTranscationInfo().getMinValue();
			if(obj[i][4].equals(0)) {
				obj[i][4] = "ͣ��";
			}
			int volume = analyse.getFiveDaysAnalysis().get(i).getTranscationInfo().getTranscationVolume().getTotalTranscationVolume() / 10000;
			if(volume < 0) {
				volume *= -1;
			}
			obj[i][5] = volume;
		}
		
		return obj;
	}
	
	/**
	 * ��ȡ�����ղص�����
	 * @return
	 */
	private Object[][] getPrivateStock() {
		PrivateStock stocks = new PrivateStock();
		List<StockCode> list = stocks.query();
		Object obj [][] = new Object[list.size()][4];
		GetStockMarketData data = new GetStockMarketData();

		//��table���������ղص�����
		for(int i = 0;i < list.size();i++) {
			StockPriceURL url = new StockPriceURL(list.get(i).getStockCode());
			data.request(url.getUrl());
			obj[i][0] = list.get(i).getStockName();
			obj[i][1] = list.get(i).getStockCode(); 
			obj[i][2] = data.getPrice();
			obj[i][3] = data.getFluctuate();
		}
		
		return obj; 
	}
	
	//���Ž����panel
	private void newsPanel() {

		//�����˲ƾ��з������������ȡ����
		SinaFinanceNewsCollection sina = new SinaFinanceNewsCollection();
		String url = "http://finance.sina.com.cn";
		// ��ȡҳ���е�<a href='xxx' [����]>��ʽ������
		sina.nodeFilterTagClass(url, "GB2312", LinkTag.class);
		List<LinkURL> urlLink = sina.getUrlList();

		//��panel��������������
		for (LinkURL link : urlLink) {
			JLabel label = new LinkLabel(link.getContext(), link.getUrl()
					.toString()); 
			label.setFont(new java.awt.Font("����", 0, 18)); // NOI18N);
			label.setText(link.getContext());
			System.out.println(link.getContext());
			jPanel8.add(label);
		}
	}

	/**
	 * �����������
	 */
	private void browser() {
		SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				browser = new WebBrowser();
				jPanel16.add(browser, BorderLayout.CENTER);
			}
		});
	}
	
	/**
	 * ��K��ͼ�������
	 */
	private void KChart() {
		SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				KChart = new WebBrowser("http://image.sinajs.cn/newchart/min/n/sh000001.gif");
				jPanel29.add(KChart, BorderLayout.CENTER);
			}
		});
	}

	//Excel�ļ��Ĺ�������
	class ExcelFileFilter extends FileFilter {
		@Override
		public String getDescription() {
			return "*.xls;*.xlsx";
		}

		@Override
		public boolean accept(File file) {
			String name = file.getName();
			return file.isDirectory() || name.toLowerCase().endsWith(".xls")
					|| name.toLowerCase().endsWith(".xlsx"); // ����ʾĿ¼��xls��xlsx�ļ�
		}
	}

	//Txt�ļ��Ĺ�������
	class TxtFileFilter extends FileFilter {
		@Override
		public String getDescription() {
			return ".txt";
		}

		@Override
		public boolean accept(File file) {
			String name = file.getName();
			return file.isDirectory() || name.toLowerCase().endsWith(".txt");
		}
	}

	//PNG�ļ��Ĺ�������
	class PngFileFilter extends FileFilter {

		@Override
		public boolean accept(File file) {
			String name = file.getName();
			return file.isDirectory() || name.toLowerCase().endsWith(".png");
		}

		@Override
		public String getDescription() {
			return ".png";
		}

	}

	//��ȡ��Ʊ�г����ݵ��߳�
	class MarketPrice implements Runnable {
		
		private GetStockMarketData data;
		
		public MarketPrice() {
			data = new GetStockMarketData();
		}
		
		public void run() {
			while(true) {
				String price = null;
				String index = null;
				//��ʼ���������ȡ���ڳ�ָ������
				data.request("http://hq.sinajs.cn/list=s_sh000001");
				price = data.getPrice();
				index = data.getStockIndex();
				
				//���ü۸�
				jLabel2.setText(price);
				//����ָ��
				jLabel3.setText(index);

				//����������ɫ
				if(Double.valueOf(index) > 0) {
					jLabel2.setForeground(new java.awt.Color(204, 0, 0));
					jLabel3.setForeground(new java.awt.Color(204, 0, 0));
				} else if(Double.valueOf(index) < 0) {
					jLabel2.setForeground(new java.awt.Color(0, 204, 0));
					jLabel3.setForeground(new java.awt.Color(0, 204, 0));
				} else {
					jLabel2.setForeground(new java.awt.Color(0, 0, 204));
					jLabel3.setForeground(new java.awt.Color(0, 0, 204));
				}
				
				//��ȡ��֤��ָ����
				data.request("http://hq.sinajs.cn/list=s_sz399001");
				//���ü۸�
				price = data.getPrice();
				//����ָ��
				index = data.getStockIndex();
				
				jLabel5.setText(price);
				jLabel6.setText(data.getStockIndex());
				//����������ɫ
				if(Double.valueOf(index) > 0) {
					jLabel5.setForeground(new java.awt.Color(204, 0, 0));
					jLabel6.setForeground(new java.awt.Color(204, 0, 0));
				} else if(Double.valueOf(index) < 0) {
					jLabel5.setForeground(new java.awt.Color(0, 204, 0));
					jLabel6.setForeground(new java.awt.Color(0, 204, 0));
				} else {
					jLabel5.setForeground(new java.awt.Color(0, 0, 204));
					jLabel6.setForeground(new java.awt.Color(0, 0, 204));
					
					jLabel5.setText("ͣ��");
				}
				
				//���÷��������ʱ�� 60s
				try {
					Thread.sleep(1000 * 60);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
		}
	}
	
	//��ȡ��ǰʱ����̣߳�ͬ��ϵͳʱ��
	class CurrentTime extends Thread {
		Date datedisplay;
		GregorianCalendar gccalendar;
		String strtime;

		public CurrentTime() {
			
		}

		@Override
		public void run() {
			while (true) {
				displaytime();
				try {
					Thread.sleep(1000);
				} catch (InterruptedException e) {
					JOptionPane.showMessageDialog(null, "�߳��ж�");
				}
			}
		}

		//��ʾʱ��
		public void displaytime() {
			datedisplay = new Date();
			gccalendar = new GregorianCalendar();
			gccalendar.setTime(datedisplay);
			strtime = "��ǰʱ��:" + gccalendar.get(Calendar.HOUR_OF_DAY) + ":"
					+ gccalendar.get(Calendar.MINUTE) + ":"
					+ gccalendar.get(Calendar.SECOND);
			jLabel11.setText(strtime);
		}
	}

	//PNG�ļ�������
	private String filePngChooser() {
		JFileChooser jfc = new JFileChooser();
		jfc.setFileSelectionMode(JFileChooser.FILES_AND_DIRECTORIES);
		PngFileFilter pngFilter = new PngFileFilter();
		jfc.addChoosableFileFilter(pngFilter);
		jfc.setFileFilter(pngFilter);
		int value = jfc.showDialog(new JLabel(), "ѡ��");
		if (value == JFileChooser.APPROVE_OPTION) {

			File file = jfc.getSelectedFile();
			file = jfc.getSelectedFile();

			return file.getAbsolutePath();
		} else {
			System.out.println("get nothing");
			return null;
		}
	}

	//Txt�ļ�������
	private String fileTxtChooser() {
		JFileChooser jfc = new JFileChooser();
		jfc.setFileSelectionMode(JFileChooser.FILES_AND_DIRECTORIES);
		TxtFileFilter txtFilter = new TxtFileFilter();
		jfc.addChoosableFileFilter(txtFilter);
		jfc.setFileFilter(txtFilter);
		int value = jfc.showDialog(new JLabel(), "ѡ��");
		if (value == JFileChooser.APPROVE_OPTION) {

			File file = jfc.getSelectedFile();
			file = jfc.getSelectedFile();
			System.out.println(file.getAbsolutePath());
			
			return file.getAbsolutePath();
		} else {
			System.out.println("get nothing");
			return null;
		}
	}

	//xls�ļ��Ĺ�����
	private String fileXlsChooser() {
		JFileChooser jfc = new JFileChooser();
		jfc.setFileSelectionMode(JFileChooser.FILES_AND_DIRECTORIES);
		ExcelFileFilter excelFilter = new ExcelFileFilter();
		jfc.addChoosableFileFilter(excelFilter);
		jfc.setFileFilter(excelFilter);
		int value = jfc.showDialog(new JLabel(), "ѡ��");
		if (value == JFileChooser.APPROVE_OPTION) {

			File file = jfc.getSelectedFile();
			file = jfc.getSelectedFile();

			return file.getAbsolutePath();

		} else {
			System.out.println("get nothing");
			return null;
		}
	}

	/**
	 * ���ҹ�Ʊ����
	 * @param text
	 * @return
	 */
	private boolean serach(String text) {
		DBQueryStockName dbQuery = new DBQueryStockName();
		return dbQuery.query(text);
	}

	/**
	 * ��ַ�������˴������д��һ��url����Ϊ�����Ե�ʵ��
	 */
	private void webGuide() {
		JLabel jLabel1 = new LinkLabel("","http://finance.sina.com.cn/stock/");
	    JLabel jLabel10 = new JLabel();
	    JLabel jLabel100 = new JLabel();
	    JLabel jLabel101 = new JLabel();
	    JLabel jLabel102 = new JLabel();
	    JLabel jLabel103 = new JLabel();
	    JLabel jLabel104 = new JLabel();
	    JLabel jLabel105 = new JLabel();
	    JLabel jLabel106 = new JLabel();
	    JLabel jLabel107 = new JLabel();
	    JLabel jLabel11 = new JLabel();
	    JLabel jLabel12 = new JLabel();
	    JLabel jLabel13 = new JLabel();
	    JLabel jLabel14 = new JLabel();
	    JLabel jLabel15 = new JLabel();
	    JLabel jLabel16 = new JLabel();
	    JLabel jLabel17 = new JLabel();
	    JLabel jLabel18 = new JLabel();
	    JLabel jLabel19 = new JLabel();
	    JLabel jLabel2 = new JLabel();
	    JLabel jLabel20 = new JLabel();
	    JLabel jLabel21 = new JLabel();
	    JLabel jLabel22 = new JLabel();
	    JLabel jLabel23 = new JLabel();
	    JLabel jLabel24 = new JLabel();
	    JLabel jLabel28 = new JLabel();
	    JLabel jLabel29 = new JLabel();
	    JLabel jLabel3 = new JLabel();
	    JLabel jLabel30 = new JLabel();
	    JLabel jLabel31 = new JLabel();
	    JLabel jLabel32 = new JLabel();
	    JLabel jLabel33 = new JLabel();
	    JLabel jLabel34 = new JLabel();
	    JLabel jLabel35 = new JLabel();
	    JLabel jLabel36 = new JLabel();
	    JLabel jLabel37 = new JLabel();
	    JLabel jLabel38 = new JLabel();
	    JLabel jLabel39 = new JLabel();
	    JLabel jLabel4 = new JLabel();
	    JLabel jLabel40 = new JLabel();
	    JLabel jLabel41 = new JLabel();
	    JLabel jLabel42 = new JLabel();
	    JLabel jLabel43 = new JLabel();
	    JLabel jLabel44 = new JLabel();
	    JLabel jLabel45 = new JLabel();
	    JLabel jLabel46 = new JLabel();
	    JLabel jLabel47 = new JLabel();
	    JLabel jLabel48 = new JLabel();
	    JLabel jLabel49 = new JLabel();
	    JLabel jLabel5 = new JLabel();
	    JLabel jLabel50 = new JLabel();
	    JLabel jLabel51 = new JLabel();
	    JLabel jLabel52 = new JLabel(); 
	    JLabel jLabel53 = new JLabel();
	    JLabel jLabel54 = new JLabel();
	    JLabel jLabel55 = new JLabel();
	    JLabel jLabel56 = new JLabel();
	    JLabel jLabel57 = new JLabel();
//	    JLabel jLabel58 = new JLabel();
	    JLabel jLabel59 = new JLabel();
	    JLabel jLabel6 = new JLabel();
	    JLabel jLabel60 = new JLabel();
	    JLabel jLabel61 = new JLabel();
	    JLabel jLabel62 = new JLabel();
	    JLabel jLabel63 = new JLabel();
	    JLabel jLabel64 = new JLabel();
	    JLabel jLabel65 = new JLabel();
	    JLabel jLabel66 = new JLabel();
	    JLabel jLabel67 = new JLabel();
	    JLabel jLabel68 = new JLabel();
	    JLabel jLabel69 = new JLabel();
	    JLabel jLabel7 = new JLabel();
	    JLabel jLabel70 = new JLabel();
	    JLabel jLabel71 = new JLabel();
	    JLabel jLabel72 = new JLabel();
	    JLabel jLabel73 = new JLabel();
	    JLabel jLabel74 = new JLabel();
	    JLabel jLabel75 = new JLabel();
	    JLabel jLabel76 = new JLabel();
	    JLabel jLabel77 = new JLabel();
	    JLabel jLabel78 = new JLabel();
	    JLabel jLabel79 = new JLabel();
	    JLabel jLabel8 = new JLabel();
	    JLabel jLabel80 = new JLabel();
	    JLabel jLabel81 = new JLabel();
	    JLabel jLabel82 = new JLabel();
	    JLabel jLabel83 = new JLabel();
	    JLabel jLabel84 = new JLabel();
	    JLabel jLabel85 = new JLabel();
	    JLabel jLabel86 = new JLabel();
	    JLabel jLabel87 = new JLabel();
	    JLabel jLabel88 = new JLabel();
	    JLabel jLabel89 = new JLabel();
	    JLabel jLabel9 = new JLabel();
	    JLabel jLabel90 = new JLabel();
	    JLabel jLabel91 = new JLabel();
	    JLabel jLabel92 = new JLabel();
	    JLabel jLabel93 = new JLabel();
	    JLabel jLabel94 = new JLabel();
	    JLabel jLabel95 = new JLabel();
	    JLabel jLabel96 = new JLabel();
	    JLabel jLabel97 = new JLabel();
	    JLabel jLabel98 = new JLabel();
	    JLabel jLabel99 = new JLabel();
	    
        jLabel84.setText("���˲ƾ�");
        jPanel2.add(jLabel84);

        jLabel1.setText("��Ʊ");
        jPanel2.add(jLabel1);

        jLabel2.setText("�¹�");
        jPanel2.add(jLabel2);

        jLabel3.setText("�۹�");
        jPanel2.add(jLabel3);

        jLabel4.setText("����");
        jPanel2.add(jLabel4);

        jLabel5.setText("����");
        jPanel2.add(jLabel5);

        jLabel6.setText("�ڻ�");
        jPanel2.add(jLabel6);

        jLabel7.setText("���");
        jPanel2.add(jLabel7);

        jLabel8.setText("�ƽ�");
        jPanel2.add(jLabel8);

        jLabel9.setText("ծȯ");
        jPanel2.add(jLabel9);

        jLabel10.setText("����");
        jPanel2.add(jLabel10);

        jLabel11.setText("����");
        jPanel2.add(jLabel11);

        jLabel12.setText("����");
        jPanel2.add(jLabel12);

        jLabel13.setText("����");
        jPanel2.add(jLabel13);

        jLabel14.setText("ר��");
        jPanel2.add(jLabel14);

        jLabel15.setText("����");
        jPanel2.add(jLabel15);

        jLabel16.setText("�ɰ�");
        jPanel2.add(jLabel16);

        jLabel17.setText("����");
        jPanel2.add(jLabel17);

        jLabel18.setText("����");
        jPanel2.add(jLabel18);

        jLabel19.setText("����");
        jPanel2.add(jLabel19);

        jLabel20.setText("��Դ");
        jPanel2.add(jLabel20);

        jLabel21.setText("����ʦ");
        jPanel2.add(jLabel21);

        jLabel85.setText("�ٶȲƾ�");
        jPanel3.add(jLabel85);

        jLabel22.setText("Ͷ��");
        jPanel3.add(jLabel22);

        jLabel23.setText("���ѽ���");
        jPanel3.add(jLabel23);

        jLabel24.setText("����");
        jPanel3.add(jLabel24);

        jLabel28.setText("��������");
        jPanel3.add(jLabel28);

        jLabel86.setText("��Ѷ�ƾ�");
        jPanel6.add(jLabel86);

        jLabel29.setText("����");
        jPanel6.add(jLabel29);

        jLabel30.setText("���");
        jPanel6.add(jLabel30);

        jLabel31.setText("����");
        jPanel6.add(jLabel31);

        jLabel32.setText("֤ȯ");
        jPanel6.add(jLabel32);

        jLabel33.setText("�۹�");
        jPanel6.add(jLabel33);

        jLabel34.setText("����");
        jPanel6.add(jLabel34);

        jLabel35.setText("����");
        jPanel6.add(jLabel35);

        jLabel36.setText("��˾");
        jPanel6.add(jLabel36);

        jLabel37.setText("����");
        jPanel6.add(jLabel37);

        jLabel38.setText("������");
        jPanel6.add(jLabel38);

        jLabel39.setText("����");
        jPanel6.add(jLabel39);

        jLabel40.setText("����");
        jPanel6.add(jLabel40);

        jLabel41.setText("����");
        jPanel6.add(jLabel41);

        jLabel87.setText("��˲ƾ�");
        jPanel10.add(jLabel87);

        jLabel42.setText("���");
        jPanel10.add(jLabel42);

        jLabel43.setText("����������");
        jPanel10.add(jLabel43);

        jLabel44.setText("��ҵ");
        jPanel10.add(jLabel44);

        jLabel45.setText("��Ʊ");
        jPanel10.add(jLabel45);

        jLabel46.setText("�۹�");
        jPanel10.add(jLabel46);

        jLabel47.setText("����");
        jPanel10.add(jLabel47);

        jLabel48.setText("iMarkets");
        jPanel10.add(jLabel48);

        jLabel49.setText("ר��");
        jPanel10.add(jLabel49);

        jLabel50.setText("���ݿ�");
        jPanel10.add(jLabel50);

        jLabel51.setText("�Ƹ���");
        jPanel10.add(jLabel51);

        jLabel52.setText("��֪��");
        jPanel10.add(jLabel52);

        jLabel53.setText("���ѻ�");
        jPanel10.add(jLabel53);

        jLabel54.setText("�ܲ�����");
        jPanel10.add(jLabel54);

        jLabel55.setText("������");
        jPanel10.add(jLabel55);

        jLabel56.setText("С����");
        jPanel10.add(jLabel56);

        jLabel57.setText("imoneyר��");
        jPanel10.add(jLabel57);

        jLabel59.setText("����");
        jPanel10.add(jLabel59);

        jLabel60.setText("����");
        jPanel10.add(jLabel60);

        jLabel61.setText("�ǻ۲�ҵ");
        jPanel10.add(jLabel61);

        jLabel88.setText("���ײƾ�");
        jPanel19.add(jLabel88);

        jLabel62.setText("���");
        jPanel19.add(jLabel62);

        jLabel63.setText("����");
        jPanel19.add(jLabel63);

        jLabel64.setText("����");
        jPanel19.add(jLabel64);

        jLabel65.setText("�ٿ�");
        jPanel19.add(jLabel65);

        jLabel66.setText("����");
        jPanel19.add(jLabel66);

        jLabel67.setText("��Ʊ");
        jPanel19.add(jLabel67);

        jLabel68.setText("����");
        jPanel19.add(jLabel68);

        jLabel69.setText("����");
        jPanel19.add(jLabel69);

        jLabel70.setText("�¹�");
        jPanel19.add(jLabel70);

        jLabel71.setText("�۹�");
        jPanel19.add(jLabel71);

        jLabel72.setText("����");
        jPanel19.add(jLabel72);

        jLabel73.setText("�ڻ�");
        jPanel19.add(jLabel73);

        jLabel74.setText("��ҵ");
        jPanel19.add(jLabel74);

        jLabel75.setText("����");
        jPanel19.add(jLabel75);

        jLabel76.setText("��Դ");
        jPanel19.add(jLabel76);

        jLabel77.setText("����");
        jPanel19.add(jLabel77);

        jLabel78.setText("����");
        jPanel19.add(jLabel78);

        jLabel79.setText("��ó");
        jPanel19.add(jLabel79);

        jLabel80.setText("����");
        jPanel19.add(jLabel80);

        jLabel81.setText("����");
        jPanel19.add(jLabel81);

        jLabel82.setText("����");
        jPanel19.add(jLabel82);

        jLabel83.setText("��ֵ");
        jPanel19.add(jLabel83);

        jLabel92.setText("������Ĳƾ�");
        jPanel14.add(jLabel92);

        jLabel89.setText("��ҵ");
        jPanel14.add(jLabel89);

        jLabel90.setText("����");
        jPanel14.add(jLabel90);

        jLabel91.setText("����");
        jPanel14.add(jLabel91);

        jLabel93.setText("�ڻ�");
        jPanel14.add(jLabel93);

        jLabel94.setText("�ƾ�");
        jPanel14.add(jLabel94);

        jLabel95.setText("�۹�");
        jPanel14.add(jLabel95);

        jLabel96.setText("����");
        jPanel14.add(jLabel96);

        jLabel97.setText("���");
        jPanel14.add(jLabel97);

        jLabel98.setText("����");
        jPanel14.add(jLabel98);

        jLabel99.setText("���");
        jPanel14.add(jLabel99);

        jLabel100.setText("�»��ƾ�");
        jPanel20.add(jLabel100);

        jLabel101.setText("����");
        jPanel20.add(jLabel101);

        jLabel102.setText("����");
        jPanel20.add(jLabel102);

        jLabel103.setText("������");
        jPanel20.add(jLabel103);

        jLabel104.setText("�Ʒ���");
        jPanel20.add(jLabel104);

        jLabel105.setText("����²�");
        jPanel20.add(jLabel105);

        jLabel106.setText("ͼ��ƾ�");
        jPanel20.add(jLabel106);

        jLabel107.setText("������");
        jPanel20.add(jLabel107);

	}

	private String getSystemDate() {
		SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd");
		return df.format(new Date());
	}

	private String getSystemWeekOfDate() {
		SimpleDateFormat df = new SimpleDateFormat("EEEE");
		return df.format(new Date());
	}

	/**
	 * @param args
	 *            the command line arguments
	 */
	public static void main(String args[]) {

		try {
			UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (InstantiationException e) {
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			e.printStackTrace();
		} catch (UnsupportedLookAndFeelException e) {
			e.printStackTrace();
		}

		NativeInterface.open();
		java.awt.EventQueue.invokeLater(new Runnable() {
			public void run() {
				new FinalExercise().setVisible(true);
			}
		});
		NativeInterface.runEventPump();
	}

    private JButton jButton1;
	private JButton jButton2;
    private JButton jButton3;
    private JButton jButton4;
    private JButton jButton5;
    private JButton jButton6;
    private JButton jButton7;
    private JButton jButton8;
    private JButton jButton9;
    private JLabel jLabel1;
    private JLabel jLabel10;
    private JLabel jLabel11;
    private JLabel jLabel12;
    private JLabel jLabel13;
    private JLabel jLabel14;
    private JLabel jLabel15;
    private JLabel jLabel16;
    private JLabel jLabel17;
    private JLabel jLabel18;
    private JLabel jLabel19;
    private JLabel jLabel2;
    private JLabel jLabel20;
    private JLabel jLabel21;
    private JLabel jLabel22;
    private JLabel jLabel23;
    private JLabel jLabel24;
    private JLabel jLabel25;
    private JLabel jLabel26;
    private JLabel jLabel27;
    private JLabel jLabel28;
    private JLabel jLabel29;
    private JLabel jLabel3;
    private JLabel jLabel30;
    private JLabel jLabel31;
    private JLabel jLabel32;
    private JLabel jLabel33;
    private JLabel jLabel34;
    private JLabel jLabel35;
    private JLabel jLabel36;
    private JLabel jLabel37;
    private JLabel jLabel38;
    private JLabel jLabel4;
    private JLabel jLabel5;
    private JLabel jLabel6;
    private JLabel jLabel7;
    private JLabel jLabel8;
    private JLabel jLabel9;
    private JMenu jMenu1;
    private JMenu jMenu2;
    private JMenu jMenu3;
    private JMenu jMenu4;
    private JMenu jMenu5;
    private JMenu jMenu6;
    private JMenuBar jMenuBar1;
    private JMenuItem jMenuItem1;
    private JMenuItem jMenuItem10;
    private JMenuItem jMenuItem2;
    private JMenuItem jMenuItem3;
    private JMenuItem jMenuItem4;
    private JMenuItem jMenuItem5;
    private JMenuItem jMenuItem6;
    private JMenuItem jMenuItem7;
    private JMenuItem jMenuItem8;
    private JMenuItem jMenuItem9;
    private JPanel jPanel1;
    private JPanel jPanel10;
    private JPanel jPanel11;
    private JPanel jPanel12;
    private JPanel jPanel13;
    private JPanel jPanel14;
    private JPanel jPanel16;
    private JPanel jPanel17;
    private JPanel jPanel18;
    private JPanel jPanel19;
    private JPanel jPanel2;
    private JPanel jPanel20;
    
    private JPanel jPanel22;
    private JPanel jPanel23;
    private JPanel jPanel24;
    private JPanel jPanel25;
    private JPanel jPanel26;
    private JPanel jPanel28;
    private JPanel jPanel29;
    private JPanel jPanel3;
    private JPanel jPanel30;
    private JPanel jPanel4;
    private JPanel jPanel5;
    private JPanel jPanel6;
    private JPanel jPanel7;
    private JPanel jPanel8;
    private JPanel jPanel9;
    private JScrollPane jScrollPane1;
    private JScrollPane jScrollPane2;
    private JTabbedPane jTabbedPane1;
    private JTable jTable1;
    private JTable jTable2;
    private JTextField jTextField1;
    
    private JPanel jPanel31;
    private JScrollPane jScrollPane3;
}
