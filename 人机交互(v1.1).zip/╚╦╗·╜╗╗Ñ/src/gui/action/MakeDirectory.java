/* ===========================================================
 * �������̿���SimpleStock
 * ===========================================================
 *
 * Copyright (C) 2015, by ZhouJiFa.
 *
 * Project Info:  SimpleStock
 *
 * ������:		��٥�� 03121394
 * ��Ҫ������Ա����ѩ      03121323
 * 			����      03121331
 * 			��ԥ      03121326
 */

package gui.action;

import java.io.File;
/**
 * 
 * @author zhoujifa
 */
public class MakeDirectory {

	public MakeDirectory() {
		
	}
	/**
	 * 
	 * @param fileName
	 */
	public static void makedir(String fileName) {
		File file = new File(fileName);
		if(!file.exists()) {
			file.mkdir();
		}
	}
	
	public static void main(String[] args) {
		MakeDirectory.makedir("stock");
	}

}
