/* ===========================================================
 * �������̿���SimpleStock
 * ===========================================================
 *
 * Copyright (C) 2015, by ZhouJiFa.
 *
 * Project Info:  SimpleStock
 *
 * ������:		��٥�� 03121394
 * ��Ҫ������Ա����ѩ      03121323
 * 			����      03121331
 * 			��ԥ      03121326
 */

package gui.action;

/**
 * @author zhoujifa
 *
 */
public class GifURL {

	private String minUrl = "http://image.sinajs.cn/newchart/min/n/";
	private String dailyUrl = "http://image.sinajs.cn/newchart/daily/n/";
	private String weekUrl = "http://image.sinajs.cn/newchart/weekly/n/";
	private String monthlyUrl = "http://image.sinajs.cn/newchart/monthly/n/";
	/**
	 * 
	 */
	public GifURL(String stockCode) {
		if(stockCode.charAt(0) >= 54) { //char '6' = 54
			minUrl = minUrl + "sh" + stockCode +".gif";
			dailyUrl = dailyUrl + "sh" + stockCode + ".gif";
			weekUrl = weekUrl + "sh" + stockCode + ".gif";
			monthlyUrl = monthlyUrl + "sh" + stockCode + ".gif";
		} else {
			minUrl = minUrl + "sz" + stockCode +".gif";
			dailyUrl = dailyUrl + "sz" + stockCode + ".gif";
			weekUrl = weekUrl + "sz" + stockCode + ".gif";
			monthlyUrl = monthlyUrl + "sz" + stockCode + ".gif";
		}
	}
	
	/**
	 * 
	 * @return minUrl
	 */
	public String getMinUrl() {
		return minUrl;
	}
	
	/**
	 * 
	 * @return dailyUrl
	 */
	public String getDailyUrl() {
		return dailyUrl;
	}
	
	/**
	 * 
	 * @return weekUrl
	 */
	public String getWeekUrl() {
		return weekUrl;
	}
	
	/**
	 * 
	 * @return monthlyUrl
	 */
	public String getMonthUrl() {
		return monthlyUrl;
	}
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		GifURL gif = new GifURL("600000");
		System.out.println(gif.getMinUrl());
		System.out.println(gif.getDailyUrl());
		System.out.println(gif.getWeekUrl());
		System.out.println(gif.getMonthUrl());
	}

}
