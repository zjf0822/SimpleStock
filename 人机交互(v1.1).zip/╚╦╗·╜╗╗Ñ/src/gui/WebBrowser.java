/* ===========================================================
 * �������̿���SimpleStock
 * ===========================================================
 *
 * Copyright (C) 2015, by ZhouJiFa.
 *
 * Project Info:  SimpleStock
 *
 * ������:		��٥�� 03121394
 * ��Ҫ������Ա����ѩ      03121323
 * 			����      03121331
 * 			��ԥ      03121326
 */

package gui;

import java.awt.BorderLayout;
import java.awt.FlowLayout;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;

import chrriis.dj.nativeswing.swtimpl.NativeInterface;
import chrriis.dj.nativeswing.swtimpl.components.JWebBrowser;
/**
 * 
 * @author zhoujifa
 */
public class WebBrowser extends JPanel {
	
	private static final long serialVersionUID = 1L;

	final static public String LS = System.getProperty("line.separator", "/n");

	final static public String FS = System.getProperty("file.separator", "//");

	final JWebBrowser webBrowser;
	
	/**
	 * 
	 * @param url
	 */
	public WebBrowser(final String url) {
		super(new BorderLayout());
		JPanel webBrowserPanel = new JPanel(new BorderLayout());
		
		//�½�һ��JWebBrowser
		webBrowser = new JWebBrowser();
		//���ù��������ɼ�
		webBrowser.setBarsVisible(false);
		//������ҳ��ַ
		webBrowser.navigate(url);
		webBrowserPanel.add(webBrowser, BorderLayout.CENTER);
		add(webBrowserPanel, BorderLayout.CENTER);

		JPanel panel = new JPanel(new FlowLayout(FlowLayout.CENTER, 4, 4));
		add(panel, BorderLayout.SOUTH);
	}

	/**
	 * 
	 */
	public WebBrowser() {
		super(new BorderLayout());
		JPanel webBrowserPanel = new JPanel(new BorderLayout());
		webBrowser = new JWebBrowser();
		webBrowser.setBarsVisible(false);
		//Ĭ����ҳ��ַ��	http://finance.sina.com.cn/stock/newstock/
		webBrowser.navigate("http://finance.sina.com.cn/stock/newstock/");
		webBrowserPanel.add(webBrowser, BorderLayout.CENTER);
		add(webBrowserPanel, BorderLayout.CENTER);

		JPanel panel = new JPanel(new FlowLayout(FlowLayout.CENTER, 4, 4));
		add(panel, BorderLayout.SOUTH);
	}
	
	/**
	 * 
	 * @param url
	 */
	//������ת��ַ
	public void forward(String url) {
		webBrowser.navigate(url);
	}
	
	public static void main(String[] args) {
		NativeInterface.open();
		SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				JFrame frame = new JFrame("java swing �����");
				frame.getContentPane().add(new WebBrowser("http://www.qq.com"),BorderLayout.CENTER);
				frame.setSize(800, 600);
				frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				frame.setVisible(true);
			}
		});
		NativeInterface.runEventPump();
		
	}
}
