/* ===========================================================
 * �������̿���SimpleStock
 * ===========================================================
 *
 * Copyright (C) 2015, by ZhouJiFa.
 *
 * Project Info:  SimpleStock
 *
 * ������:		��٥�� 03121394
 * ��Ҫ������Ա����ѩ      03121323
 * 			����      03121331
 * 			��ԥ      03121326
 */

package gui;

import java.util.ArrayList;
import java.util.List;

/**
 * @author zhoujifa
 * ��ȡָ�����ڵķ�Χ
 */
public class DateRange {

	private List<String> dayList;		//��¼���ڷ�Χ�ڵ�����
	
	/**
	 * 
	 * @param beginday
	 * @param endday
	 * @return
	 */
	public int days(String beginday,String endday) {
		int begin = Integer.valueOf(beginday.substring(8));
		int end = Integer.valueOf(endday.substring(8));
		
		return end - begin + 1;
	}
	
	/**
	 * 
	 * @param beginday
	 * @param endday
	 * @return
	 */
	public List<String> dayList(String beginday,String endday) {
		String day = beginday.substring(0,8);
		int addition = Integer.valueOf(beginday.substring(8));
		
		for(int i = 0;i < days(beginday, endday);i++) {
			if((addition + i) < 10) {
				dayList.add(day + "0" + (addition + i));
			} else {
				dayList.add(day + (addition + i));
			}
		}
		
		return dayList;
	}
	
	/**
	 * Constructor Method
	 */
	public DateRange() {
		// TODO Auto-generated constructor stub
		dayList = new ArrayList();
	}
	
	public static void main(String[] args) {
		DateRange range = new DateRange();
		System.out.println(range.days("2015-05-04", "2015-05-06"));
		for(String s : range.dayList("2015-05-04", "2015-05-16")) {
			System.out.println(s);
		}
	}

}
