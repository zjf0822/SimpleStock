/* ===========================================================
 * �������̿���SimpleStock
 * ===========================================================
 *
 * Copyright (C) 2015, by ZhouJiFa.
 *
 * Project Info:  SimpleStock
 *
 * ������:		��٥�� 03121394
 * ��Ҫ������Ա����ѩ      03121323
 * 			����      03121331
 * 			��ԥ      03121326
 */

package gui;

import gui.action.DownloadFile;
import gui.message.DownloadMessage;

import java.awt.BorderLayout;
import java.awt.FlowLayout;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFileChooser;
import javax.swing.JPanel;
import javax.swing.WindowConstants;
import javax.swing.border.EmptyBorder;
import javax.swing.filechooser.FileFilter;
import javax.swing.JTextField;
import javax.swing.JLabel;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.io.File;

import jxcell.data.OutputDataToExcel;

public class DownloadXlsDialog extends JDialog {

	private final JPanel contentPanel = new JPanel();
	private JTextField textField;			//�ı���
	private int pressTimes;					//�����������
	private String folder;					//�ļ���·��
	
	private Chooser dateChooser1;			//��ʼ����ѡ����
	private Chooser dateChooser2;			//��������ѡ����
	private JButton okButton;				//ȷ������
	
	private String downloadPath;			//����·��
	
	//excel�ļ�������
	class ExcelFileFilter extends FileFilter {
		/**
		 * ����xls ��xlsx�ļ�
		 */
		public String getDescription() {
			return "*.xls;*.xlsx";
		}
		
		/**
		 * ��׺��ƥ����ļ����£�
		 */
		public boolean accept(File file) {
			String name = file.getName();
			return file.isDirectory() || name.toLowerCase().endsWith(".xls")
					|| name.toLowerCase().endsWith(".xlsx"); // ����ʾĿ¼��xls��xlsx�ļ�
		}
	}

	/**
	 * 
	 * @return
	 */
	private String fileXlsChooser() {
		//�����ļ�ѡ����
		JFileChooser jfc = new JFileChooser();
		jfc.setFileSelectionMode(JFileChooser.FILES_AND_DIRECTORIES);
		//Excel�ļ�������
		ExcelFileFilter excelFilter = new ExcelFileFilter();
		jfc.addChoosableFileFilter(excelFilter);
		jfc.setFileFilter(excelFilter);
		int value = jfc.showDialog(new JLabel(), "ѡ��");
		//ѡ���ļ�
		if (value == JFileChooser.APPROVE_OPTION) {

			File file = jfc.getSelectedFile();
			file = jfc.getSelectedFile();

			//�����ļ��ľ���·��
			return file.getAbsolutePath();

		} 
		//δѡ���ļ�
		else {
			System.out.println("get nothing");
			//�����ļ�·��Ϊnull
			return null;
		}
	}
	
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		try {
			DownloadXlsDialog dialog = new DownloadXlsDialog();
			dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			dialog.setVisible(true);
			
			System.out.println(dialog.getDownloadPath());
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Create the dialog.
	 */
	public DownloadXlsDialog() {
		
		//ѡ���ļ��Ŀ�ʼ·��
		final Chooser dateChooser1 = Chooser.getInstance("yyyy-MM-dd");
    	//ѡ���ļ��Ľ���·��
		final Chooser dateChooser2 = Chooser.getInstance("yyyy-MM-dd");
		
		setBounds(100, 100, 425, 115);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setLayout(new FlowLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		{
			textField = new JTextField("�����Ʊ����");
			contentPanel.add(textField);
			textField.setColumns(10);
		}
		{
			JPanel buttonPane = new JPanel();
			buttonPane.setLayout(new FlowLayout(FlowLayout.CENTER));
			getContentPane().add(buttonPane, BorderLayout.SOUTH);
			{
				JLabel lblNewLabel_1 = new JLabel("���뿪ʼ����");
				dateChooser1.register(lblNewLabel_1);
				buttonPane.add(lblNewLabel_1);
			}
			{
				okButton = new JButton("ѡ���ļ�λ��");
				okButton.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent arg0) {
						if(pressTimes > 0) {
							String begin = dateChooser1.getSelectDate();
							String end = dateChooser2.getSelectDate();
							String stockCode = textField.getText();
							if(stockCode.charAt(0) >= 54) {
								stockCode = "sh" + stockCode; 
							} else {
								stockCode = "sz" + stockCode;
							}
							
							DownloadFile download = new DownloadFile();
							download.setFolder(folder);
							
							DateRange range = new DateRange();
							for(String s :range.dayList(begin, end)) {
								if(Week.getWeekdayOfDateTime(s) != 6 && Week.getWeekdayOfDateTime(s) != 0) {
									download.downloadNet(s, stockCode);
									System.out.println(download.getFilePath());
									OutputDataToExcel out = new OutputDataToExcel();
									String filename = download.getFilePath();
									out.setFilePath(filename, filename.substring(0, filename.length() - 3) + "xls");
									out.output();
									setDownloadPath(filename.substring(0, filename.length() - 3) + "xls");
								}
							}
							
							DownloadMessage dialog = new DownloadMessage("�ù����½��׿�ʼ����");
							dialog.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
							dialog.setVisible(true);
							
						} else {
							folder = fileXlsChooser();
							okButton.setText("����");
							pressTimes++;
						}
					}
				});
				buttonPane.add(okButton);
				getRootPane().setDefaultButton(okButton);
			}
			{
				JLabel lblNewLabel = new JLabel("�����������");
				dateChooser2.register(lblNewLabel);
				buttonPane.add(lblNewLabel);
			}
		}
	}

	/**
	 * 
	 * @return
	 */
	public String getDownloadPath() {
		return downloadPath;
	}

	/**
	 * 
	 * @param downloadPath
	 */
	public void setDownloadPath(String downloadPath) {
		this.downloadPath = downloadPath;
	}

}
