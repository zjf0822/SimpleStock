/* ===========================================================
 * �������̿���SimpleStock
 * ===========================================================
 *
 * Copyright (C) 2015, by ZhouJiFa.
 *
 * Project Info:  SimpleStock
 *
 * ������:		��٥�� 03121394
 * ��Ҫ������Ա����ѩ      03121323
 * 			����      03121331
 * 			��ԥ      03121326
 */

package gui;

import java.awt.Color;
import java.awt.Cursor;
import java.awt.Desktop;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URISyntaxException;
import java.net.URL;

import javax.swing.JLabel;
/**
 * 
 * �������ı���ǩ��
 * @author zhoujifa
 *
 */
public class LinkLabel extends JLabel {
    private static final long serialVersionUID = 1L;
    /** ��������ʾ������ */
    private String text;
    /** �������� */
    private URL link = null;
    /** �����ǩ��Ĭ����ɫ */
    private Color preColor = null;

    /** * ����һ�������� * @param vText ��ʾ������ * @param vLink ���ӵ�ַ */
    /**
     * 
     * @param vText
     * @param vLink
     */
    public LinkLabel(String vText, String vLink) {
        this.text = vText;
        try {
            if (!vLink.startsWith("http://")) {
                vLink = "http://" + vLink;
            }
            this.link = new URL(vLink);
        } catch (MalformedURLException err) {
            err.printStackTrace();
        }
        this.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseExited(MouseEvent e) {
                LinkLabel.this.setCursor(Cursor
                        .getPredefinedCursor(Cursor.DEFAULT_CURSOR));
                if (preColor != null)
                    LinkLabel.this.setForeground(preColor);
            }

            @Override
            public void mouseEntered(MouseEvent e) {
                LinkLabel.this.setCursor(Cursor
                        .getPredefinedCursor(Cursor.HAND_CURSOR));
                preColor = LinkLabel.this.getForeground();
                LinkLabel.this.setForeground(Color.BLUE);
            }

            @Override
            public void mouseClicked(MouseEvent e) {
                try {
                    Desktop.getDesktop().browse(link.toURI());
                } catch (IOException err) {
                    err.printStackTrace();
                } catch (URISyntaxException err) {
                    err.printStackTrace();
                }
            }
        });
    }
}
