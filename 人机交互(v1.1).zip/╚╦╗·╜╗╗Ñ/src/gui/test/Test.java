/* ===========================================================
 * �������̿���SimpleStock
 * ===========================================================
 *
 * Copyright (C) 2015, by ZhouJiFa.
 *
 * Project Info:  SimpleStock
 *
 * ������:		��٥�� 03121394
 * ��Ҫ������Ա����ѩ      03121323
 * 			����      03121331
 * 			��ԥ      03121326
 */

package gui.test;

import gui.Week;
import gui.action.DownloadFile;

import java.util.ArrayList;
import java.util.List;

import jstockchart.analysing.AnalyseFiveDaysImpl;

/**
 * @author Administrator
 *
 */
public class Test {

	@org.junit.Test
	public void getFiveDaysAnalyse() {
		Object obj [][] = new Object[5][6];
		List<String> fiveFilePaths = new ArrayList<String>();
		
		//��֤��ʼ���϶�����ĳһֻ��Ʊ��Ϣ
		String	code = "600000";
		if(code.charAt(0) >= 54) { //char '6' = 54
			code = "sh" + code;
		} else {
			code = "sz" + code;
		}
		
		Week weeks = new Week();
		List<String> list = weeks.getDateList();
		DownloadFile download = new DownloadFile();
		for(String day : list) {
			download.downloadNet(day, code);
			fiveFilePaths.add(download.getFilePath());
		}
		AnalyseFiveDaysImpl a = new AnalyseFiveDaysImpl(fiveFilePaths);
		a.analyse();
		for(int i = 0;i < fiveFilePaths.size();i++) {
			obj[i][0] = list.get(i);
			
			obj[i][1] = a.getFiveDaysAnalysis().get(i).
					getTranscationInfo().getBeginValue();
			
			obj[i][2] = a.getFiveDaysAnalysis().get(i).
					getTranscationInfo().getEndValue();
			
			obj[i][3] = a.getFiveDaysAnalysis().get(i).
					getTranscationInfo().getMaxValue();
			
			obj[i][4] = a.getFiveDaysAnalysis().get(i).
					getTranscationInfo().getMinValue();
			
			obj[i][5] = a.getFiveDaysAnalysis().get(i).
					getTranscationInfo().getTranscationVolume().
					getTotalTranscationVolume();
		}
	}
}
