/* ===========================================================
 * �������̿���SimpleStock
 * ===========================================================
 *
 * Copyright (C) 2015, by ZhouJiFa.
 *
 * Project Info:  SimpleStock
 *
 * ������:		��٥�� 03121394
 * ��Ҫ������Ա����ѩ      03121323
 * 			����      03121331
 * 			��ԥ      03121326
 */

package gui.test;

import gui.Week;
import gui.action.DownloadFile;

import java.util.ArrayList;
import java.util.List;

import jstockchart.analysing.AnalyseFiveDaysImpl;

public class FiveCategory {

	
	
	public static void main(String[] args) {
		List<String> fiveFilePaths = new ArrayList<String>();
		Week weeks = new Week();
		List<String> list = weeks.getDateList();
		DownloadFile download = new DownloadFile();
		for(String day : list) {
			download.downloadNet(day, "sh600000");
			fiveFilePaths.add(download.getFilePath());
			System.out.println(download.getFilePath());
		}
		
		AnalyseFiveDaysImpl a = new AnalyseFiveDaysImpl(fiveFilePaths);
		a.analyse();
		
		System.out.println(a.getFiveDaysAnalysis().get(0).getTranscationInfo().getBeginValue());
		System.out.println(a.getFiveDaysAnalysis().get(1).getTranscationInfo().getBeginValue());
		System.out.println(a.getFiveDaysAnalysis().get(2).getTranscationInfo().getBeginValue());
		System.out.println(a.getFiveDaysAnalysis().get(3).getTranscationInfo().getBeginValue());
		System.out.println(a.getFiveDaysAnalysis().get(4).getTranscationInfo().getBeginValue());
	}

}
