package gui.test;

import static org.junit.Assert.*;

import org.junit.Test;

public class TestStr {

	@Test
	public void test() {
		String str = "C:\\Users\\MyPC\\Desktop\\��ͼ";
		
		String strs[] = str.split("\\\\");
		str = "";
		for(int i = 0;i < strs.length;i++) {
			str = str + strs[i] + "/";
		}
//		SaveAsPNG png = new SaveAsPNG(str+"/stock.png", plot);
		System.out.println("PictureSavePath" + str + "stock.png");

	}

}
