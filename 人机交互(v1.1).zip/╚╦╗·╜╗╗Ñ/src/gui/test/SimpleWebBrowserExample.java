/* ===========================================================
 * �������̿���SimpleStock
 * ===========================================================
 *
 * Copyright (C) 2015, by ZhouJiFa.
 *
 * Project Info:  SimpleStock
 *
 * ������:		��٥�� 03121394
 * ��Ҫ������Ա����ѩ      03121323
 * 			����      03121331
 * 			��ԥ      03121326
 */

package gui.test;

/*
 * Christopher Deckers (chrriis@nextencia.net)
 * http://www.nextencia.net
 *
 * See the file "readme.txt" for information on usage and redistribution of
 * this file, and for a DISCLAIMER OF ALL WARRANTIES.
 */

import java.awt.BorderLayout;
import javax.swing.BorderFactory;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;

import chrriis.common.UIUtils;
import chrriis.dj.nativeswing.swtimpl.NativeInterface;
import chrriis.dj.nativeswing.swtimpl.components.JWebBrowser;

/**
 * @author zhoujifa
 */
public class SimpleWebBrowserExample extends JPanel {

	private final JWebBrowser webBrowser;
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public SimpleWebBrowserExample() {
		super(new BorderLayout());
		JPanel webBrowserPanel = new JPanel(new BorderLayout());
		webBrowserPanel.setBorder(BorderFactory
				.createTitledBorder("Native Web Browser component"));
		webBrowser = new JWebBrowser();
		webBrowser.navigate("http://finance.sina.com.cn/");
		webBrowserPanel.add(webBrowser, BorderLayout.CENTER);
		add(webBrowserPanel, BorderLayout.CENTER);
	}
	
	public SimpleWebBrowserExample(String url) {
		super(new BorderLayout());
		JPanel webBrowserPanel = new JPanel(new BorderLayout());

		webBrowser = new JWebBrowser();
		webBrowser.navigate(url);
		webBrowserPanel.add(webBrowser, BorderLayout.CENTER);
		add(webBrowserPanel, BorderLayout.CENTER);
	}
	
	public void forward(String url) {
		webBrowser.navigate(url);
	}

	/* Standard main method to try that test as a standalone application. */
	public static void main(String[] args) {
		UIUtils.setPreferredLookAndFeel();
		NativeInterface.open();
		SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				JFrame frame = new JFrame("DJ Native Swing Test");
				
				frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				SimpleWebBrowserExample browser = new SimpleWebBrowserExample();
				browser.forward("http://finance.sina.com.cn/stock/newstock/");
				frame.getContentPane().add(browser,BorderLayout.CENTER);
				frame.setSize(800, 600);
				frame.setLocationByPlatform(true);
				frame.setVisible(true);
			}
		});
		NativeInterface.runEventPump();
	}
}
