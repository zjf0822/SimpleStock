/* ===========================================================
 * �������̿���SimpleStock
 * ===========================================================
 *
 * Copyright (C) 2015, by ZhouJiFa.
 *
 * Project Info:  SimpleStock
 *
 * ������:		��٥�� 03121394
 * ��Ҫ������Ա����ѩ      03121323
 * 			����      03121331
 * 			��ԥ      03121326
 */

package gui.test;

import gui.LinkLabel;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import java.awt.FlowLayout;

import javax.swing.JLabel;
/**
 * 
 * @author zhoujifa
 */
public class TestCreateLabel extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					TestCreateLabel frame = new TestCreateLabel();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public TestCreateLabel() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(new FlowLayout(FlowLayout.CENTER, 5, 5));
		
		JLabel lblNewLabel = new JLabel("zjf      ");
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("yx           ");
		contentPane.add(lblNewLabel_1);
		String url[] = {"www.baidu.com","www.hao123.com","www.qq.com","www.tudou.com","www.163.com","www.baidu.com",
				"www.hao123.com","www.qq.com"};
		for(int i = 0;i < 8;i++) {
			JLabel label = new LinkLabel("abdjzldjfaiosjfdnweoscdknfoiwefsjdncnwoa;sjd =" + i + " ",url[i]);
			contentPane.add(label);
		}
	}

}
