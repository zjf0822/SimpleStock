/* ===========================================================
 * �������̿���SimpleStock
 * ===========================================================
 *
 * Copyright (C) 2015, by ZhouJiFa.
 *
 * Project Info:  SimpleStock
 *
 * ������:		��٥�� 03121394
 * ��Ҫ������Ա����ѩ      03121323
 * 			����      03121331
 * 			��ԥ      03121326
 */

package gui;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.List;
/**
 * 
 * @author zhoujifa
 */
public class Week {
	
	private static final int FIRST_DAY = Calendar.MONDAY;
	
	private List<String> date;
	
	public Week() {
		date = new ArrayList<String>();
	}
	
	public List<String> getDateList() {
		printWeekdays();
		Collections.reverse(date);
		return date;
	}

	public void printWeekdays() {
		Calendar calendar = Calendar.getInstance();
		calendar.add(Calendar.DATE, -1);
		for (int i = 0; i < 7; i++) {
			printDay(calendar);
			calendar.add(Calendar.DATE, -1);
		}
	}

	private void printDay(Calendar calendar) {
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		String timeStr = calendar.getTime().toString();
		if((timeStr.contains("Sun") || timeStr.contains("Sat")) != true) { 
//			System.out.println(calendar.getTime());
			date.add(dateFormat.format(calendar.getTime()));
//			System.out.println(dateFormat.format(calendar.getTime()));
		}
	}
	
	public static int getWeekdayOfDateTime(String datetime){
		SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd"); 
		Calendar c = Calendar.getInstance();   
		try {
			c.setTime(df.parse(datetime));
		} catch (Exception e) {
			e.printStackTrace();
		}
		return c.get(Calendar.DAY_OF_WEEK)-1;
	}
	
	/**
	 * �������յ�����
	 * @return
	 */
	public static String yesterday() {
		Calendar calendar = Calendar.getInstance();
		calendar.add(Calendar.DATE, -1);
		String yesterday = new SimpleDateFormat( "yyyy-MM-dd").format(calendar.getTime());
		if(getWeekdayOfDateTime(yesterday) == 6) {
			calendar.add(Calendar.DATE, -1);
			yesterday = new SimpleDateFormat( "yyyy-MM-dd").format(calendar.getTime());
		}
		if(getWeekdayOfDateTime(yesterday) == 0) {
			calendar.add(Calendar.DATE, -2);
			yesterday = new SimpleDateFormat( "yyyy-MM-dd").format(calendar.getTime());
		}
		return yesterday;
	}
	
	public static void main(String[] args) {
		Week week = new Week();
//		week.printWeekdays();
		
		Calendar calendar = Calendar.getInstance();
		
		System.out.println(getWeekdayOfDateTime("2015-06-14"));
		System.out.println(Week.yesterday());
		
//		for(String str : week.getDateList()) {
//			System.out.println(str);
//		}
	}
}
