/* ===========================================================
 * �������̿���SimpleStock
 * ===========================================================
 *
 * Copyright (C) 2015, by ZhouJiFa.
 *
 * Project Info:  SimpleStock
 *
 * ������:		��٥�� 03121394
 * ��Ҫ������Ա����ѩ      03121323
 * 			����      03121331
 * 			��ԥ      03121326
 */

package gui;

import java.awt.*;

import javax.swing.*;

import java.util.*;
/**
 * ��ȡϵͳ��ǰʱ�䣬ͬ��ʱ��
 * @author zhoujifa
 */
public class GetCurrentTime extends JFrame {
	JPanel pnlmain;
	static JLabel lblmove;		//��ʾʱ���label
	
	currenttime ct;

	public GetCurrentTime() {
		pnlmain = new JPanel();
		this.setContentPane(pnlmain);
		lblmove = new JLabel();
		lblmove.setFont(new Font("����", Font.BOLD, 22));
		lblmove.setForeground(Color.RED);
		pnlmain.add(lblmove);
		ct = new currenttime();
		ct.start();
		setTitle("�߳�");
		setSize(250, 150);
		setVisible(true);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setResizable(false);
	}

	public static void main(String args[]) {
		new GetCurrentTime();
	}
}

//��ȡʱ����߳�
class currenttime extends Thread {
	Date datedisplay;
	GregorianCalendar gccalendar;
	String strtime;

	public currenttime() {
	}

	@Override
	public void run() {
		while (true) {
			displaytime();
			try {
				//Ĭ��1sͬ��һ��
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				JOptionPane.showMessageDialog(null, "�߳��ж�");
			}
		}
	}

	/**
	 * ��ʾʱ��ķ���
	 */
	public void displaytime() {
		datedisplay = new Date();
		gccalendar = new GregorianCalendar();
		gccalendar.setTime(datedisplay);
		strtime = "��ǰʱ��:" + gccalendar.get(Calendar.HOUR_OF_DAY) + ":"
				+ gccalendar.get(Calendar.MINUTE) + ":"
				+ gccalendar.get(Calendar.SECOND);
		GetCurrentTime.lblmove.setText(strtime);
	}
}
